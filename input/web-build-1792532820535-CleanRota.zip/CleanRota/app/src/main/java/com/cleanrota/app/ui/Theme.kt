package com.cleanrota.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

val TealDark = Color(0xFF004D40)
val Teal = Color(0xFF00796B)
val TealLight = Color(0xFF26A69A)
val Amber = Color(0xFFFFB300)

private val LightColors = lightColorScheme(
    primary = Teal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5F0EC),
    onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFF4A6360),
    secondaryContainer = Color(0xFFE3EFED),
    onSecondaryContainer = Color(0xFF0B2B27),
    tertiary = Color(0xFFB26A00),
    tertiaryContainer = Color(0xFFFFE9C2),
    onTertiaryContainer = Color(0xFF3B2600),
    background = Color(0xFFF4F9F8),
    surface = Color(0xFFF4F9F8),
    surfaceVariant = Color(0xFFE6EEEC),
    onSurfaceVariant = Color(0xFF3F4947)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DB6AC),
    onPrimary = Color(0xFF003732),
    primaryContainer = Color(0xFF00504A),
    onPrimaryContainer = Color(0xFFB2DFDB),
    secondaryContainer = Color(0xFF1F3835),
    onSecondaryContainer = Color(0xFFD7EFEB),
    tertiary = Color(0xFFFFB74D),
    tertiaryContainer = Color(0xFF4A3300),
    onTertiaryContainer = Color(0xFFFFE9C2),
    background = Color(0xFF0E1514),
    surface = Color(0xFF0E1514),
    surfaceVariant = Color(0xFF1B2523),
    onSurfaceVariant = Color(0xFFBFC9C6)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun CleanRotaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        shapes = AppShapes,
        content = content
    )
}

private val arabic: Locale = Locale.forLanguageTag("ar")
private val fullFmt = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", arabic)
private val dayFmt = DateTimeFormatter.ofPattern("d", arabic)
private val monthFmt = DateTimeFormatter.ofPattern("MMM", arabic)
private val weekdayFmt = DateTimeFormatter.ofPattern("EEEE", arabic)

fun LocalDate.arFull(): String = format(fullFmt)
fun LocalDate.arDay(): String = format(dayFmt)
fun LocalDate.arMonth(): String = format(monthFmt)
fun LocalDate.arWeekday(): String = format(weekdayFmt)
