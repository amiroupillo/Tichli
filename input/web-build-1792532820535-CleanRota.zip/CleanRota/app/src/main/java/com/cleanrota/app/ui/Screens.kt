package com.cleanrota.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cleanrota.app.domain.MemberStats
import com.cleanrota.app.domain.RotaState
import com.cleanrota.app.domain.Scheduler
import com.cleanrota.app.domain.Stats
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

// ════════════════════════════ الهيكل العام ════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RotaApp(vm: RotaViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    val titles = listOf("جدول التنظيف", "أفراد الفريق", "الإحصاءات", "السجل")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(titles[tab], fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                actions = {
                    if (tab == 0) {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavTab(tab == 0, { tab = 0 }, Icons.Default.DateRange, "الجدول")
                NavTab(tab == 1, { tab = 1 }, Icons.Default.Person, "الأفراد")
                NavTab(tab == 2, { tab = 2 }, BarChartIcon, "الإحصاءات")
                NavTab(tab == 3, { tab = 3 }, Icons.Default.CheckCircle, "السجل")
            }
        },
        floatingActionButton = {
            if (tab == 1) {
                FloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة فرد") }
            }
        }
    ) { padding ->
        val mod = Modifier.padding(padding)
        when (tab) {
            0 -> ScheduleScreen(
                state = state,
                onSetSub = vm::setSubstitute,
                onClearSub = vm::clearSubstitute,
                onComplete = vm::completeSession,
                modifier = mod
            )
            1 -> MembersScreen(
                state = state,
                onToggle = vm::setActive,
                onRename = vm::renameMember,
                onDelete = vm::deleteMember,
                modifier = mod
            )
            2 -> StatsScreen(state = state, modifier = mod)
            else -> HistoryScreen(state = state, modifier = mod)
        }
    }

    if (showAdd) {
        NameDialog(
            title = "إضافة فرد",
            initial = "",
            confirmLabel = "إضافة",
            isTaken = { Scheduler.isNameTaken(state, it) },
            onDismiss = { showAdd = false },
            onConfirm = { vm.addMember(it); showAdd = false }
        )
    }
    if (showSettings) {
        SettingsDialog(state = state, onDismiss = { showSettings = false }, onSetStart = vm::setStartDate)
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.NavTab(
    selected: Boolean,
    onClick: () -> Unit,
    icon: ImageVector,
    label: String
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null) },
        label = { Text(label) }
    )
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
    }
}

// ════════════════════════════ شاشة الجدول ════════════════════════════

private val HeroBrush = Brush.linearGradient(listOf(TealDark, Teal, TealLight))

@Composable
fun ScheduleScreen(
    state: RotaState,
    onSetSub: (absentId: String, substituteId: String) -> Unit,
    onClearSub: (String) -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val names = remember(state.members) { state.members.associate { it.id to it.name } }
    val today = LocalDate.now()
    val base = Scheduler.currentTeam(state)

    if (base.isEmpty()) {
        EmptyState(
            Icons.Default.Person,
            "ابدأ بإضافة الأفراد",
            "أضف أفراد الفريق من تبويب «الأفراد» ليبدأ التطبيق بتوزيع مهام التنظيف.",
            modifier
        )
        return
    }

    val date = Scheduler.sessionDate(state.startDate, state.sessionIndex)
    val exempt = Scheduler.exemptApplied(state)
    val projByDate = remember(state) { Scheduler.project(state, 8).associateBy { it.date } }
    val meetings = remember(state.startDate) { Scheduler.meetingsFrom(state.startDate, today, 8) }
    var subFor by remember { mutableStateOf<String?>(null) }
    var confirmDone by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ── بطاقة موعد التنظيف القادم ──
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(Modifier.background(HeroBrush).padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("يوم التنظيف القادم", style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.8f))
                            Text(date.arWeekday(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(date.arFull(), style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.9f))
                            Spacer(Modifier.height(8.dp))
                            Pill(relativeLabel(date, today), Color.White.copy(alpha = 0.2f), Color.White)
                        }
                        DateBlock(date, Color.White.copy(alpha = 0.2f), Color.White)
                    }

                    if (base.size < Scheduler.TEAM_SIZE) {
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, null, tint = Amber)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "عدد الأفراد النشطين أقل من ${Scheduler.TEAM_SIZE}؛ أضف أفرادًا لاكتمال الفريق.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("فريق التنظيف", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(alpha = 0.85f))
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        base.forEach { id ->
                            val sub = state.pending.firstOrNull { it.absentId == id }?.substituteId
                            HeroTeamRow(
                                name = names[id] ?: "؟",
                                substituteName = sub?.let { names[it] },
                                onReplace = { subFor = id },
                                onClear = { onClearSub(id) }
                            )
                        }
                    }

                    if (exempt.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "معفى من هذا الموعد (خدم بديلًا سابقًا): " + exempt.joinToString("، ") { names[it] ?: "؟" },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { confirmDone = true },
                        enabled = date <= today,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = TealDark,
                            disabledContainerColor = Color.White.copy(alpha = 0.25f),
                            disabledContentColor = Color.White.copy(alpha = 0.8f)
                        )
                    ) {
                        Text(
                            if (date <= today) "تم التنظيف ✓" else "التأكيد متاح يوم الموعد",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // ── اللقاءات القادمة ──
        item {
            Column(Modifier.padding(top = 8.dp)) {
                Text("اللقاءات القادمة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "تلتقي المجموعة كل 8 أيام، ويكون التنظيف فقط حين يصادف اللقاء يوم الثلاثاء.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(meetings) { d ->
            val cleaning = Scheduler.isCleaningDay(d)
            val session = projByDate[d]
            MeetingRow(
                date = d,
                cleaning = cleaning,
                teamNames = session?.team?.map { names[it] ?: "؟" } ?: emptyList()
            )
        }
    }

    // ── اختيار البديل ──
    subFor?.let { absentId ->
        val candidates = Scheduler.eligibleSubstitutes(state, absentId)
        AlertDialog(
            onDismissRequest = { subFor = null },
            shape = RoundedCornerShape(24.dp),
            title = { Text("بديل ${names[absentId] ?: ""}") },
            text = {
                if (candidates.isEmpty()) {
                    Text("لا يوجد أفراد متاحون ليكونوا بدلاء. أضف فردًا جديدًا أو فعّل فردًا معطّلًا.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        candidates.forEach { id ->
                            val pos = state.queue.indexOf(id) + 1
                            ListItem(
                                leadingContent = { Avatar(names[id] ?: "؟", 38.dp) },
                                headlineContent = { Text(names[id] ?: "؟") },
                                supportingContent = { Text("ترتيبه في الدور: $pos") },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clickable {
                                    onSetSub(absentId, id)
                                    subFor = null
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { subFor = null }) { Text("إلغاء") } }
        )
    }

    // ── تأكيد الإتمام ──
    if (confirmDone) {
        AlertDialog(
            onDismissRequest = { confirmDone = false },
            shape = RoundedCornerShape(24.dp),
            title = { Text("تأكيد إتمام التنظيف") },
            text = {
                Text(
                    "سيُسجَّل الموعد في السجل والإحصاءات ويتقدّم الدور. " +
                        "الغائبون يُبرمجون في الموعد التالي، ومشاركة البدلاء تُحتسب بدل دورهم القادم."
                )
            },
            confirmButton = { TextButton(onClick = { onComplete(); confirmDone = false }) { Text("تأكيد") } },
            dismissButton = { TextButton(onClick = { confirmDone = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun HeroTeamRow(name: String, substituteName: String?, onReplace: () -> Unit, onClear: () -> Unit) {
    val textButton = ButtonDefaults.textButtonColors(contentColor = Color.White)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(substituteName ?: name, 42.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            if (substituteName == null) {
                Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color.White)
            } else {
                Text(
                    name,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f),
                    textDecoration = TextDecoration.LineThrough
                )
                Text(
                    "البديل: $substituteName",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    "$name يُبرمج في التنظيف التالي",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
        if (substituteName == null) {
            TextButton(onClick = onReplace, colors = textButton) { Text("غائب؟") }
        } else {
            TextButton(onClick = onReplace, colors = textButton) { Text("تغيير") }
            TextButton(onClick = onClear, colors = textButton) { Text("إلغاء") }
        }
    }
}

@Composable
private fun MeetingRow(date: LocalDate, cleaning: Boolean, teamNames: List<String>) {
    val scheme = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = if (cleaning) scheme.primaryContainer else scheme.surfaceVariant),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            DateBlock(
                date,
                container = if (cleaning) scheme.primary else scheme.onSurfaceVariant.copy(alpha = 0.18f),
                content = if (cleaning) scheme.onPrimary else scheme.onSurfaceVariant
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(date.arWeekday(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                if (cleaning) {
                    Pill("يوم تنظيف", scheme.primary, scheme.onPrimary)
                    if (teamNames.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(teamNames.joinToString("  •  "), style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    Pill("لقاء بدون تنظيف", scheme.surface, scheme.onSurfaceVariant)
                }
            }
        }
    }
}

private fun relativeLabel(date: LocalDate, today: LocalDate): String {
    val d = ChronoUnit.DAYS.between(today, date)
    return when {
        d == 0L -> "اليوم"
        d == 1L -> "غدًا"
        d == 2L -> "بعد يومين"
        d in 3L..10L -> "بعد $d أيام"
        d > 10L -> "بعد $d يومًا"
        d == -1L -> "متأخر بيوم واحد"
        d == -2L -> "متأخر بيومين"
        else -> "متأخر منذ ${-d} يومًا"
    }
}

// ════════════════════════════ شاشة الأفراد ════════════════════════════

@Composable
fun MembersScreen(
    state: RotaState,
    onToggle: (String, Boolean) -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var editing by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }

    // النشطون بترتيب الدور ثم المعطّلون
    val ordered = remember(state) {
        val byId = state.members.associateBy { it.id }
        state.queue.mapNotNull { byId[it] } + state.members.filter { !it.active }
    }

    if (ordered.isEmpty()) {
        EmptyState(
            Icons.Default.Person,
            "القائمة فارغة",
            "اضغط زر (+) لإضافة أول فرد. يلزم 3 أفراد على الأقل لتكوين فريق.",
            modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "${state.queue.size} نشط من ${state.members.size} • الترتيب = ترتيب الدور القادم",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(ordered, key = { it.id }) { m ->
            val pos = state.queue.indexOf(m.id) + 1
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.alpha(if (m.active) 1f else 0.6f)
            ) {
                Row(
                    Modifier.padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(m.name, 46.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (m.active) {
                            Pill("الترتيب $pos", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                        } else {
                            Text("غير متاح مؤقتًا", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Switch(checked = m.active, onCheckedChange = { onToggle(m.id, it) })
                    IconButton(onClick = { editing = m.id }) { Icon(Icons.Default.Edit, "تحرير") }
                    IconButton(onClick = { deleting = m.id }) { Icon(Icons.Default.Delete, "حذف") }
                }
            }
        }
    }

    editing?.let { id ->
        val member = state.members.firstOrNull { it.id == id }
        if (member != null) {
            NameDialog(
                title = "تحرير الاسم",
                initial = member.name,
                confirmLabel = "حفظ",
                isTaken = { Scheduler.isNameTaken(state, it, exceptId = id) },
                onDismiss = { editing = null },
                onConfirm = { onRename(id, it); editing = null }
            )
        } else editing = null
    }

    deleting?.let { id ->
        val member = state.members.firstOrNull { it.id == id }
        AlertDialog(
            onDismissRequest = { deleting = null },
            shape = RoundedCornerShape(24.dp),
            title = { Text("حذف ${member?.name ?: ""}؟") },
            text = { Text("سيُحذف من القائمة والدور، ويبقى اسمه في السجل والإحصاءات. للغياب المؤقت استخدم المفتاح بدل الحذف.") },
            confirmButton = { TextButton(onClick = { onDelete(id); deleting = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    isTaken: (String) -> Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    val trimmed = text.trim()
    val taken = trimmed.isNotEmpty() && isTaken(trimmed)

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("الاسم") },
                isError = taken,
                supportingText = { if (taken) Text("هذا الاسم موجود مسبقًا") }
            )
        },
        confirmButton = {
            TextButton(enabled = trimmed.isNotEmpty() && !taken, onClick = { onConfirm(trimmed) }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ════════════════════════════ شاشة الإحصاءات ════════════════════════════

@Composable
fun StatsScreen(state: RotaState, modifier: Modifier = Modifier) {
    val stats = remember(state) { Stats.compute(state) }
    val maxPart = (stats.perMember.maxOfOrNull { it.participations } ?: 0).coerceAtLeast(1)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryTile(stats.sessions.toString(), "مرات التنظيف", Modifier.weight(1f))
                SummaryTile(stats.substitutions.toString(), "استبدالات", Modifier.weight(1f))
                SummaryTile(state.queue.size.toString(), "أفراد نشطون", Modifier.weight(1f))
            }
        }
        if (stats.sessions == 0) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Text(
                        "ستظهر تفاصيل مشاركة كل فرد هنا بعد تأكيد أول موعد تنظيف.",
                        Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        } else {
            item {
                Text(
                    "آخر تنظيف: ${stats.lastDate?.arFull() ?: "-"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item { Text("مشاركة كل فرد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(stats.perMember, key = { it.name }) { m -> MemberStatCard(m, maxPart) }
    }
}

@Composable
private fun SummaryTile(value: String, label: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun MemberStatCard(m: MemberStats, maxPart: Int) {
    val scheme = MaterialTheme.colorScheme
    val frac = m.participations.toFloat() / maxPart
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(m.name, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (!m.inRota) {
                            Spacer(Modifier.width(8.dp))
                            Pill("محذوف", scheme.tertiaryContainer, scheme.onTertiaryContainer)
                        }
                    }
                    Text(
                        m.lastDate?.let { "آخر مشاركة: ${it.arDay()} ${it.arMonth()} ${it.year}" } ?: "لم يشارك بعد",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(m.participations.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = scheme.primary)
                    Text("مشاركة", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(scheme.surface)) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(50)).background(scheme.primary))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill("بدوره ${m.ownTurns}", scheme.primaryContainer, scheme.onPrimaryContainer)
                Pill("كبديل ${m.asSubstitute}", scheme.secondaryContainer, scheme.onSecondaryContainer)
                Pill("استُبدل ${m.timesReplaced}", scheme.tertiaryContainer, scheme.onTertiaryContainer)
                Spacer(Modifier.weight(1f))
                Text("${m.sharePercent}%", style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
            }
        }
    }
}

// ════════════════════════════ شاشة السجل ════════════════════════════

@Composable
fun HistoryScreen(state: RotaState, modifier: Modifier = Modifier) {
    if (state.history.isEmpty()) {
        EmptyState(
            Icons.Default.CheckCircle,
            "لا توجد مواعيد منجزة",
            "بعد تأكيد أول موعد تنظيف سيظهر هنا سجل كامل بمن نظّف ومن استُبدل.",
            modifier
        )
        return
    }
    val scheme = MaterialTheme.colorScheme
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(state.history.asReversed()) { h ->
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    DateBlock(h.date, scheme.primary, scheme.onPrimary)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(h.date.arWeekday(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(h.team.joinToString("  •  "), style = MaterialTheme.typography.bodyMedium)
                        h.substitutions.forEach { (absent, sub) ->
                            Spacer(Modifier.height(4.dp))
                            Pill("$sub بدلًا من $absent", scheme.tertiaryContainer, scheme.onTertiaryContainer)
                        }
                    }
                }
            }
        }
    }
}

// ════════════════════════════ الإعدادات ════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(state: RotaState, onDismiss: () -> Unit, onSetStart: (LocalDate) -> Unit) {
    var picking by remember { mutableStateOf(false) }
    val editable = state.history.isEmpty()

    if (picking) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = state.startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { picking = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let {
                        onSetStart(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                    picking = false
                }) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { picking = false }) { Text("إلغاء") } }
        ) { DatePicker(state = pickerState) }
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("الإعدادات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("تاريخ أول لقاء للمجموعة", style = MaterialTheme.typography.labelLarge)
                Text(state.startDate.arFull(), style = MaterialTheme.typography.titleMedium)
                if (editable) {
                    TextButton(onClick = { picking = true }) { Text("تغيير التاريخ") }
                } else {
                    Text("لا يمكن تغييره بعد إتمام أول موعد.", style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(12.dp))
                Text("كيف تُحسب المواعيد؟", style = MaterialTheme.typography.labelLarge)
                Text(
                    "• تلتقي المجموعة كل 8 أيام من تاريخ أول لقاء.\n" +
                        "• التنظيف فقط في اللقاء الذي يصادف يوم الثلاثاء (مرة كل 7 لقاءات = 56 يومًا).\n" +
                        "• الفريق = 3 أفراد بالتناوب.\n" +
                        "• الغائب يُبرمج في موعد التنظيف التالي.\n" +
                        "• مشاركة البديل تُحتسب بدل دوره القادم، ويُعفى من الموعد التالي إن كان ضمن فريقه.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}
