package com.cleanrota.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.UUID

/**
 * منطق الجدولة (Kotlin صِرف بلا اعتماد على Android كي يمكن اختباره على JVM).
 *
 * ── قواعد التاريخ ───────────────────────────────────────────────
 * • المجموعة تلتقي كل 8 أيام بدءًا من startDate (اللقاء k = startDate + 8k).
 * • التنظيف يُقام فقط في اللقاء الذي يصادف يوم الثلاثاء، وغيره لقاء بلا تنظيف.
 * • بما أن 8 ≡ 1 (mod 7) فيتقدّم يوم الأسبوع بيوم واحد في كل لقاء، فيصادف الثلاثاء
 *   مرة كل 7 لقاءات، أي كل 56 يومًا بالضبط.
 *
 * ── قواعد الدور ─────────────────────────────────────────────────
 * queue = طابور الأفراد النشطين. فريق الموعد = أول 3 في الطابور.
 * بعد كل موعد تنظيف: من خدم يذهب لنهاية الطابور.
 *
 * ── قاعدة البديل ────────────────────────────────────────────────
 * • الغائب لا تُحتسب له مشاركة، فيتقدّم لأول الطابور ← يُبرمج في موعد التنظيف التالي.
 * • مشاركة البديل تُحتسب بدلًا من دوره القادم: يُنقل من موضعه إلى آخر الطابور.
 * • يُعفى البديل من الموعد التالي إذا كان ضمن فريقه (exemptNext).
 */
object Scheduler {

    const val TEAM_SIZE = 3
    const val MEETING_DAYS = 8L
    val CLEANING_DAY: DayOfWeek = DayOfWeek.TUESDAY

    // ───────────────────────── اللقاءات والتواريخ ─────────────────

    fun meetingDate(start: LocalDate, k: Int): LocalDate = start.plusDays(MEETING_DAYS * k)

    fun isCleaningDay(date: LocalDate): Boolean = date.dayOfWeek == CLEANING_DAY

    /** تاريخ موعد التنظيف رقم [n] (يبدأ من 0): اللقاءات التي تصادف الثلاثاء فقط. */
    fun sessionDate(start: LocalDate, n: Int): LocalDate {
        val d = Math.floorMod(CLEANING_DAY.value - start.dayOfWeek.value, 7) // عدد اللقاءات حتى أول ثلاثاء
        return start.plusDays(MEETING_DAYS * d + MEETING_DAYS * 7 * n)
    }

    /** أول [count] لقاء يقع في [from] أو بعده. */
    fun meetingsFrom(start: LocalDate, from: LocalDate, count: Int): List<LocalDate> {
        val days = ChronoUnit.DAYS.between(start, from)
        val k0 = if (days <= 0) 0L else (days + MEETING_DAYS - 1) / MEETING_DAYS
        return (0 until count).map { meetingDate(start, (k0 + it).toInt()) }
    }

    // ───────────────────────── الفريق ───────────────────────────

    /** يختار أول [TEAM_SIZE] من الطابور متخطيًا المعفَين، إلا إذا لم يبقَ عدد كافٍ. */
    fun pickTeam(queue: List<String>, exempt: Collection<String>): List<String> {
        val eligible = queue.filter { it !in exempt }
        val pool = if (eligible.size >= TEAM_SIZE) eligible else eligible + queue.filter { it in exempt }
        return pool.take(TEAM_SIZE)
    }

    /** الفريق الأصلي لموعد التنظيف القادم قبل أي استبدال. */
    fun currentTeam(state: RotaState): List<String> = pickTeam(state.queue, state.exemptNext)

    /** الفريق الفعلي بعد تطبيق الاستبدالات المسجّلة. */
    fun finalTeam(state: RotaState): List<String> =
        currentTeam(state).map { id -> state.pending.firstOrNull { it.absentId == id }?.substituteId ?: id }

    /** من أُعفي فعلًا من الموعد القادم (كان سيقع في الفريق لولا الإعفاء). */
    fun exemptApplied(state: RotaState): List<String> {
        val eligible = state.queue.count { it !in state.exemptNext }
        if (eligible < TEAM_SIZE) return emptyList()
        return state.queue.take(TEAM_SIZE).filter { it in state.exemptNext }
    }

    // ───────────────────────── الاستبدال ────────────────────────

    /** المرشحون ليكونوا بدلاء: نشطون، ليسوا في الفريق، وغير مستخدَمين بديلًا لغائب آخر. */
    fun eligibleSubstitutes(state: RotaState, absentId: String): List<String> {
        val base = currentTeam(state)
        val usedElsewhere = state.pending.filter { it.absentId != absentId }.map { it.substituteId }.toSet()
        return state.queue.filter { it !in base && it !in usedElsewhere }
    }

    fun setSubstitution(state: RotaState, absentId: String, substituteId: String): RotaState {
        if (absentId !in currentTeam(state)) return state
        if (substituteId !in eligibleSubstitutes(state, absentId)) return state
        val others = state.pending.filter { it.absentId != absentId }
        return state.copy(pending = others + Substitution(absentId, substituteId))
    }

    fun clearSubstitution(state: RotaState, absentId: String): RotaState =
        state.copy(pending = state.pending.filter { it.absentId != absentId })

    // ───────────────────────── إتمام موعد ───────────────────────

    fun completeSession(state: RotaState): RotaState {
        val s = normalize(state)
        val base = currentTeam(s)
        if (base.isEmpty()) return s

        val subs = s.pending
        val absentIds = subs.map { it.absentId }
        val subIds = subs.map { it.substituteId }

        val finalTeam = base.map { id -> subs.firstOrNull { it.absentId == id }?.substituteId ?: id }
        val served = base.filter { it !in absentIds } + subIds          // البدلاء في آخر القائمة عمدًا
        val remaining = s.queue.filter { it !in served && it !in absentIds }

        val names = s.members.associate { it.id to it.name }
        val entry = HistoryEntry(
            date = sessionDate(s.startDate, s.sessionIndex),
            team = finalTeam.map { names[it] ?: "؟" },
            substitutions = subs.map { (names[it.absentId] ?: "؟") to (names[it.substituteId] ?: "؟") }
        )

        return s.copy(
            queue = absentIds + remaining + served,   // الغائب أولًا ← يُبرمج في الموعد التالي
            sessionIndex = s.sessionIndex + 1,
            pending = emptyList(),
            exemptNext = subIds,                       // إعفاء البدلاء من الموعد التالي
            history = s.history + entry
        )
    }

    /** يحسب مواعيد التنظيف القادمة (الأول يتضمن الاستبدالات المسجّلة، والبقية بلا غياب). */
    fun project(state: RotaState, count: Int): List<ProjectedSession> {
        val out = mutableListOf<ProjectedSession>()
        var s = normalize(state)
        for (i in 0 until count) {
            if (s.queue.isEmpty()) break
            out += ProjectedSession(
                sessionIndex = s.sessionIndex,
                date = sessionDate(s.startDate, s.sessionIndex),
                team = finalTeam(s),
                substitutions = s.pending,
                exemptApplied = exemptApplied(s)
            )
            s = completeSession(s)
        }
        return out
    }

    // ───────────────────────── إدارة الأفراد ────────────────────

    fun isNameTaken(state: RotaState, name: String, exceptId: String? = null): Boolean =
        state.members.any { it.id != exceptId && it.name.equals(name.trim(), ignoreCase = true) }

    /** الفرد الجديد يدخل آخر الطابور. */
    fun addMember(state: RotaState, name: String, id: String = UUID.randomUUID().toString()): RotaState {
        val clean = name.trim()
        if (clean.isEmpty() || isNameTaken(state, clean)) return state
        return normalize(state.copy(members = state.members + Member(id, clean), queue = state.queue + id))
    }

    /** يغيّر الاسم ويحدّث السجل أيضًا كي تبقى الإحصاءات متصلة بالفرد نفسه. */
    fun renameMember(state: RotaState, id: String, newName: String): RotaState {
        val clean = newName.trim()
        val old = state.members.firstOrNull { it.id == id }?.name ?: return state
        if (clean.isEmpty() || isNameTaken(state, clean, exceptId = id)) return state
        fun r(n: String) = if (n == old) clean else n
        return state.copy(
            members = state.members.map { if (it.id == id) it.copy(name = clean) else it },
            history = state.history.map { h ->
                h.copy(team = h.team.map(::r), substitutions = h.substitutions.map { (a, b) -> r(a) to r(b) })
            }
        )
    }

    /** تعطيل فرد = إخراجه من الدور مؤقتًا؛ تفعيله = دخوله آخر الطابور. */
    fun setActive(state: RotaState, id: String, active: Boolean): RotaState {
        val m = state.members.firstOrNull { it.id == id } ?: return state
        if (m.active == active) return state
        val members = state.members.map { if (it.id == id) it.copy(active = active) else it }
        val queue = if (active) state.queue + id else state.queue - id
        return normalize(state.copy(members = members, queue = queue))
    }

    fun deleteMember(state: RotaState, id: String): RotaState =
        normalize(
            state.copy(
                members = state.members.filter { it.id != id },
                queue = state.queue.filter { it != id }
            )
        )

    /** تغيير تاريخ أول لقاء مسموح فقط قبل إتمام أي موعد. */
    fun setStartDate(state: RotaState, date: LocalDate): RotaState =
        if (state.history.isNotEmpty()) state else state.copy(startDate = date, sessionIndex = 0)

    // ───────────────────────── تنظيف الحالة ─────────────────────

    /** يضمن اتساق الحالة بعد أي تعديل على الأفراد (طابور، استبدالات، إعفاءات). */
    internal fun normalize(s: RotaState): RotaState {
        val activeIds = s.members.filter { it.active }.map { it.id }
        val kept = s.queue.filter { it in activeIds }.distinct()
        val queue = kept + activeIds.filter { it !in kept }
        val exempt = s.exemptNext.filter { it in activeIds }
        val base = pickTeam(queue, exempt)
        val seenSubs = mutableSetOf<String>()
        val pending = s.pending
            .distinctBy { it.absentId }
            .filter { p ->
                p.absentId in base &&
                    p.substituteId in activeIds &&
                    p.substituteId !in base &&
                    seenSubs.add(p.substituteId)
            }
        return s.copy(queue = queue, exemptNext = exempt, pending = pending)
    }
}
