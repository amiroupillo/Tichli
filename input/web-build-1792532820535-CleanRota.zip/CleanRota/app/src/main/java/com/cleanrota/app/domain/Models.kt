package com.cleanrota.app.domain

import java.time.LocalDate

/** فرد في الفريق. [active] = false يعني غير متاح مؤقتًا (يبقى في القائمة لكن خارج الدور). */
data class Member(val id: String, val name: String, val active: Boolean = true)

/** استبدال: [substituteId] يحل محل [absentId] في موعد التنظيف القادم. */
data class Substitution(val absentId: String, val substituteId: String)

/** سجل موعد تنظيف تمّ. نخزّن الأسماء (لا المعرّفات) كي يبقى السجل مقروءًا حتى بعد حذف فرد. */
data class HistoryEntry(
    val date: LocalDate,
    val team: List<String>,
    val substitutions: List<Pair<String, String>> // (اسم الغائب, اسم البديل)
)

/**
 * حالة الجدولة الكاملة (غير قابلة للتعديل؛ كل عملية تُرجع حالة جديدة).
 *
 * @property startDate    تاريخ أول لقاء للمجموعة (اللقاءات = startDate + 8 × k).
 * @property queue        ترتيب الدور للأفراد النشطين؛ أول 3 = فريق موعد التنظيف القادم.
 * @property sessionIndex رقم موعد التنظيف القادم (0 = أول موعد تنظيف).
 * @property pending      الاستبدالات المسجّلة لموعد التنظيف القادم.
 * @property exemptNext   البدلاء المعفَون من موعد التنظيف التالي (قاعدة الإعفاء).
 */
data class RotaState(
    val startDate: LocalDate,
    val members: List<Member> = emptyList(),
    val queue: List<String> = emptyList(),
    val sessionIndex: Int = 0,
    val pending: List<Substitution> = emptyList(),
    val exemptNext: List<String> = emptyList(),
    val history: List<HistoryEntry> = emptyList()
)

/** موعد تنظيف متوقَّع للعرض في الواجهة. */
data class ProjectedSession(
    val sessionIndex: Int,
    val date: LocalDate,
    val team: List<String>,                 // معرّفات الفريق النهائي بعد الاستبدال
    val substitutions: List<Substitution>,
    val exemptApplied: List<String>         // من أُعفي فعلًا من هذا الموعد
)
