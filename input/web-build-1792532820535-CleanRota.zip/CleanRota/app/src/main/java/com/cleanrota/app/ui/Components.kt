package com.cleanrota.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val avatarColors = listOf(
    0xFF00897B, 0xFF5C6BC0, 0xFFEF6C00, 0xFF8E24AA,
    0xFF3949AB, 0xFFD81B60, 0xFF039BE5, 0xFF7CB342
).map { Color(it) }

/** دائرة ملوّنة بأول حرف من الاسم؛ اللون ثابت لكل اسم. */
@Composable
fun Avatar(name: String, size: Dp = 42.dp, modifier: Modifier = Modifier) {
    val color = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = name.trim().take(1),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp
        )
    }
}

/** كتلة تاريخ على شكل بطاقة تقويم صغيرة (شهر فوق، يوم تحت). */
@Composable
fun DateBlock(date: LocalDate, container: Color, content: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(container)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(date.arMonth(), style = MaterialTheme.typography.labelMedium, color = content)
        Text(date.arDay(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = content)
    }
}

/** شارة صغيرة مستديرة. */
@Composable
fun Pill(text: String, container: Color, content: Color, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(50), color = container, modifier = modifier) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium,
            color = content
        )
    }
}

/** أيقونة مخطط أعمدة (غير موجودة في مجموعة الأيقونات الأساسية). */
val BarChartIcon: ImageVector by lazy {
    ImageVector.Builder(
        name = "BarChart",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).addPath(
        pathData = PathParser().parsePathString("M5,9.2h3V19H5zM10.6,5h2.8v14h-2.8zM16.2,13H19v6h-2.8z").toNodes(),
        fill = SolidColor(Color.Black)
    ).build()
}
