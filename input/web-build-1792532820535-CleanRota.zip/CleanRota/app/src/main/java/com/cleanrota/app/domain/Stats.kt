package com.cleanrota.app.domain

import java.time.LocalDate

/** إحصاءات فرد واحد محسوبة من السجل. */
data class MemberStats(
    val name: String,
    val participations: Int,   // كل مرة نظّف فيها فعليًا (بدوره أو كبديل)
    val ownTurns: Int,         // منها بدوره الأصلي
    val asSubstitute: Int,     // منها كبديل عن غائب
    val timesReplaced: Int,    // كم مرة غاب واستُبدل
    val lastDate: LocalDate?,
    val sharePercent: Int,     // حصته من إجمالي المشاركات
    val inRota: Boolean        // false = محذوف من القائمة لكنه في السجل
)

data class RotaStats(
    val sessions: Int,
    val substitutions: Int,
    val lastDate: LocalDate?,
    val perMember: List<MemberStats>
)

object Stats {

    fun compute(state: RotaState): RotaStats {
        val h = state.history
        val currentNames = state.members.map { it.name }
        val historyNames = h.flatMap { e -> e.team + e.substitutions.flatMap { listOf(it.first, it.second) } }
        val deletedNames = historyNames.distinct().filter { it !in currentNames }
        val totalSlots = h.sumOf { it.team.size }

        val rows = (currentNames + deletedNames).map { name ->
            val part = h.count { name in it.team }
            val sub = h.sumOf { e -> e.substitutions.count { it.second == name } }
            val replaced = h.sumOf { e -> e.substitutions.count { it.first == name } }
            MemberStats(
                name = name,
                participations = part,
                ownTurns = part - sub,
                asSubstitute = sub,
                timesReplaced = replaced,
                lastDate = h.lastOrNull { name in it.team }?.date,
                sharePercent = if (totalSlots == 0) 0 else Math.round(part * 100f / totalSlots),
                inRota = name in currentNames
            )
        }.sortedWith(compareByDescending<MemberStats> { it.participations }.thenBy { it.name })

        return RotaStats(
            sessions = h.size,
            substitutions = h.sumOf { it.substitutions.size },
            lastDate = h.lastOrNull()?.date,
            perMember = rows
        )
    }
}
