package com.cleanrota.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SchedulerTest {

    private val start = LocalDate.of(2026, 10, 20) // ثلاثاء

    private fun rota(vararg names: String, startDate: LocalDate = start): RotaState =
        names.fold(RotaState(startDate = startDate)) { s, n -> Scheduler.addMember(s, n, id = n) }

    private fun teams(state: RotaState, n: Int) = Scheduler.project(state, n).map { it.team }

    // ───────────── التواريخ: لقاء كل 8 أيام، تنظيف عند الثلاثاء فقط ─────────────

    @Test
    fun `cleaning happens only on meetings that fall on Tuesday`() {
        for (s in listOf(start, start.plusDays(1), start.plusDays(2), start.plusDays(5), start.plusDays(6))) {
            val tuesdayMeetings = (0..400).map { Scheduler.meetingDate(s, it) }.filter { it.dayOfWeek == DayOfWeek.TUESDAY }
            val sessions = tuesdayMeetings.indices.map { Scheduler.sessionDate(s, it) }
            assertEquals(tuesdayMeetings, sessions)
            assertTrue(sessions.all { ChronoUnit.DAYS.between(s, it) % 8L == 0L })
        }
    }

    @Test
    fun `cleaning repeats every 56 days`() {
        val gaps = (0..50).map { Scheduler.sessionDate(start, it) }.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b) }
        assertTrue(gaps.all { it == 56L })
    }

    @Test
    fun `first date examples`() {
        assertEquals(LocalDate.of(2026, 10, 20), Scheduler.sessionDate(start, 0))
        assertEquals(LocalDate.of(2026, 12, 15), Scheduler.sessionDate(start, 1))
        // أول لقاء جمعة 23/10 ← أول لقاء يصادف ثلاثاء هو بعد 4 لقاءات (32 يومًا)
        assertEquals(LocalDate.of(2026, 11, 24), Scheduler.sessionDate(LocalDate.of(2026, 10, 23), 0))
        // أول لقاء أربعاء 21/10 ← بعد 6 لقاءات (48 يومًا)
        assertEquals(LocalDate.of(2026, 12, 8), Scheduler.sessionDate(LocalDate.of(2026, 10, 21), 0))
    }

    @Test
    fun `meetings are every 8 days`() {
        val m = Scheduler.meetingsFrom(start, start, 4)
        assertEquals(
            listOf(LocalDate.of(2026, 10, 20), LocalDate.of(2026, 10, 28), LocalDate.of(2026, 11, 5), LocalDate.of(2026, 11, 13)),
            m
        )
        assertEquals(LocalDate.of(2026, 10, 28), Scheduler.meetingsFrom(start, LocalDate.of(2026, 10, 21), 1).single())
        assertEquals(LocalDate.of(2026, 10, 20), Scheduler.meetingsFrom(start, LocalDate.of(2026, 1, 1), 1).single())
        assertEquals(LocalDate.of(2026, 10, 28), Scheduler.meetingsFrom(start, LocalDate.of(2026, 10, 28), 1).single())
        assertTrue(Scheduler.isCleaningDay(start))
        assertFalse(Scheduler.isCleaningDay(LocalDate.of(2026, 10, 28)))
    }

    // ───────────── الدور ─────────────

    @Test
    fun `plain rotation with 6 members`() {
        val t = teams(rota("A", "B", "C", "D", "E", "F"), 3)
        assertEquals(listOf(listOf("A", "B", "C"), listOf("D", "E", "F"), listOf("A", "B", "C")), t)
    }

    @Test
    fun `plain rotation with 7 members wraps around`() {
        val t = teams(rota("A", "B", "C", "D", "E", "F", "G"), 3)
        assertEquals(listOf(listOf("A", "B", "C"), listOf("D", "E", "F"), listOf("G", "A", "B")), t)
    }

    @Test
    fun `equal participation over a long run without absences`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        val count = mutableMapOf<String, Int>()
        repeat(70) {
            Scheduler.finalTeam(s).forEach { count[it] = (count[it] ?: 0) + 1 }
            s = Scheduler.completeSession(s)
        }
        assertTrue(count.values.all { it == 30 })
    }

    @Test
    fun `fewer than three members gives a smaller team`() {
        val s = rota("A", "B")
        assertEquals(listOf("A", "B"), Scheduler.currentTeam(s))
        assertEquals(2, Scheduler.project(s, 3).first().team.size)
    }

    // ───────────── قاعدة البديل ─────────────

    @Test
    fun `absent person returns next time and substitute counts instead of his turn`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, absentId = "B", substituteId = "F")
        assertEquals(listOf("A", "F", "C"), Scheduler.finalTeam(s))

        s = Scheduler.completeSession(s)
        assertEquals(listOf("B", "D", "E", "G", "A", "C", "F"), s.queue)
        assertEquals(listOf("F"), s.exemptNext)
        assertEquals(listOf("B", "D", "E"), Scheduler.finalTeam(s))
        assertEquals(listOf("G", "A", "C"), teams(s, 2)[1])
        assertEquals(listOf("F", "B", "D"), teams(s, 3)[2])
    }

    @Test
    fun `substitute who was next in line is exempt from the next appointment`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, "B", "D")
        s = Scheduler.completeSession(s)
        val next = teams(s, 2)
        assertEquals(listOf("B", "E", "F"), next[0])
        assertFalse("D" in next[0])
        assertFalse("D" in next[1])
    }

    @Test
    fun `exempt members are skipped only when enough others exist`() {
        assertEquals(listOf("A", "B", "C"), Scheduler.pickTeam(listOf("D", "A", "B", "C"), listOf("D")))
        assertEquals(listOf("A", "B", "C"), Scheduler.pickTeam(listOf("A", "B", "C"), listOf("C")))
    }

    @Test
    fun `exemption is reported for the next session`() {
        val s = RotaState(
            startDate = start,
            members = listOf("D", "A", "B", "C").map { Member(it, it) },
            queue = listOf("D", "A", "B", "C"),
            exemptNext = listOf("D")
        )
        assertEquals(listOf("D"), Scheduler.exemptApplied(s))
        assertEquals(listOf("A", "B", "C"), Scheduler.finalTeam(s))
    }

    @Test
    fun `two substitutions in the same session`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, "A", "E")
        s = Scheduler.setSubstitution(s, "B", "F")
        assertEquals(listOf("E", "F", "C"), Scheduler.finalTeam(s))
        s = Scheduler.completeSession(s)
        assertEquals(listOf("A", "B", "D", "G", "C", "E", "F"), s.queue)
    }

    @Test
    fun `invalid substitutions are rejected`() {
        val s = rota("A", "B", "C", "D", "E", "F", "G")
        assertEquals(s, Scheduler.setSubstitution(s, "A", "B"))
        assertEquals(s, Scheduler.setSubstitution(s, "D", "E"))
        val withInactive = Scheduler.setActive(s, "F", false)
        assertEquals(withInactive, Scheduler.setSubstitution(withInactive, "A", "F"))
        val one = Scheduler.setSubstitution(s, "A", "D")
        assertEquals(one, Scheduler.setSubstitution(one, "B", "D"))
    }

    @Test
    fun `clearing a substitution restores the original team`() {
        var s = Scheduler.setSubstitution(rota("A", "B", "C", "D"), "A", "D")
        s = Scheduler.clearSubstitution(s, "A")
        assertEquals(listOf("A", "B", "C"), Scheduler.finalTeam(s))
    }

    @Test
    fun `with four members the exempt substitute is not in the next team`() {
        var s = Scheduler.setSubstitution(rota("A", "B", "C", "D"), "A", "D")
        s = Scheduler.completeSession(s)
        assertEquals(listOf("A", "B", "C"), Scheduler.finalTeam(s))
    }

    // ───────────── إدارة الأفراد ─────────────

    @Test
    fun `add edit and delete members`() {
        var s = rota("A", "B", "C")
        s = Scheduler.addMember(s, "  D ", id = "D")
        assertEquals(listOf("A", "B", "C", "D"), s.queue)
        assertEquals(s, Scheduler.addMember(s, "d"))
        s = Scheduler.renameMember(s, "D", "Dina")
        assertEquals("Dina", s.members.first { it.id == "D" }.name)
        s = Scheduler.deleteMember(s, "B")
        assertEquals(listOf("A", "C", "D"), s.queue)
        assertEquals(3, s.members.size)
    }

    @Test
    fun `rename also updates history so statistics stay linked`() {
        var s = Scheduler.setSubstitution(rota("A", "B", "C", "D", "E"), "A", "E")
        s = Scheduler.completeSession(s)
        s = Scheduler.renameMember(s, "E", "Eman")
        s = Scheduler.renameMember(s, "A", "Adam")
        val h = s.history.single()
        assertEquals(listOf("Eman", "B", "C"), h.team)
        assertEquals(listOf("Adam" to "Eman"), h.substitutions)
    }

    @Test
    fun `deactivating removes from queue and reactivating appends`() {
        var s = rota("A", "B", "C", "D")
        s = Scheduler.setActive(s, "B", false)
        assertEquals(listOf("A", "C", "D"), s.queue)
        s = Scheduler.setActive(s, "B", true)
        assertEquals(listOf("A", "C", "D", "B"), s.queue)
    }

    @Test
    fun `member edits drop invalid pending substitutions`() {
        val base = Scheduler.setSubstitution(rota("A", "B", "C", "D", "E", "F", "G"), "B", "F")
        assertTrue(Scheduler.deleteMember(base, "F").pending.isEmpty())
        assertTrue(Scheduler.setActive(base, "B", false).pending.isEmpty())
        assertTrue(Scheduler.deleteMember(base, "B").pending.isEmpty())
    }

    @Test
    fun `history keeps names after a member is deleted`() {
        var s = Scheduler.completeSession(rota("A", "B", "C", "D"))
        s = Scheduler.deleteMember(s, "A")
        assertEquals(listOf("A", "B", "C"), s.history.single().team)
    }

    @Test
    fun `start date only changeable before first session`() {
        val s = rota("A", "B", "C")
        val moved = Scheduler.setStartDate(s, LocalDate.of(2026, 10, 23))
        assertEquals(LocalDate.of(2026, 11, 24), Scheduler.sessionDate(moved.startDate, moved.sessionIndex))
        val after = Scheduler.completeSession(s)
        assertEquals(after, Scheduler.setStartDate(after, LocalDate.of(2027, 1, 1)))
    }

    // ───────────── الإحصاءات ─────────────

    @Test
    fun `statistics count participation substitutions and replacements`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, "B", "F")
        s = Scheduler.completeSession(s)      // A, F(بديل عن B), C
        s = Scheduler.completeSession(s)      // B, D, E
        val st = Stats.compute(s)
        assertEquals(2, st.sessions)
        assertEquals(1, st.substitutions)
        val by = st.perMember.associateBy { it.name }
        assertEquals(1, by.getValue("F").participations)
        assertEquals(1, by.getValue("F").asSubstitute)
        assertEquals(0, by.getValue("F").ownTurns)
        assertEquals(1, by.getValue("B").timesReplaced)
        assertEquals(1, by.getValue("B").participations)
        assertEquals(0, by.getValue("G").participations)
        assertEquals(6, st.perMember.sumOf { it.participations })
        assertEquals(17, by.getValue("A").sharePercent) // 1/6
        assertEquals(Scheduler.sessionDate(start, 1), by.getValue("B").lastDate)
    }

    @Test
    fun `statistics keep deleted members flagged`() {
        var s = Scheduler.completeSession(rota("A", "B", "C", "D"))
        s = Scheduler.deleteMember(s, "A")
        val a = Stats.compute(s).perMember.first { it.name == "A" }
        assertEquals(1, a.participations)
        assertFalse(a.inRota)
    }

    // ───────────── خصائص عامة (عشوائية بذرة ثابتة) ─────────────

    @Test
    fun `random absences never break invariants`() {
        val rnd = Random(42)
        var s = rota("A", "B", "C", "D", "E", "F", "G", "H")
        val ids = s.members.map { it.id }.toSet()
        repeat(400) {
            val base = Scheduler.currentTeam(s)
            if (rnd.nextInt(3) == 0) {
                val absent = base.random(rnd)
                val cands = Scheduler.eligibleSubstitutes(s, absent)
                if (cands.isNotEmpty()) s = Scheduler.setSubstitution(s, absent, cands.random(rnd))
            }
            val team = Scheduler.finalTeam(s)
            assertEquals(3, team.size)
            assertEquals(3, team.toSet().size)
            assertEquals(ids, s.queue.toSet())
            assertEquals(s.queue.size, s.queue.toSet().size)
            assertEquals(DayOfWeek.TUESDAY, Scheduler.sessionDate(s.startDate, s.sessionIndex).dayOfWeek)
            s = Scheduler.completeSession(s)
            val absentees = s.queue.take(s.history.last().substitutions.size)
            assertEquals(absentees.toSet(), Scheduler.currentTeam(s).take(absentees.size).toSet())
        }
    }

    @Test
    fun `project first entry reflects pending substitutions`() {
        val s = Scheduler.setSubstitution(rota("A", "B", "C", "D", "E"), "A", "E")
        val p = Scheduler.project(s, 4)
        assertEquals(4, p.size)
        assertEquals(listOf("E", "B", "C"), p[0].team)
        assertEquals(listOf("A", "D", "B").toSet(), p[1].team.toSet())
        assertTrue(p.all { it.date.dayOfWeek == DayOfWeek.TUESDAY })
    }
}
