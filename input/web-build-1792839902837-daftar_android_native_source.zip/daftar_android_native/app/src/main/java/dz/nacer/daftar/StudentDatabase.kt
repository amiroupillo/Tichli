package dz.nacer.daftar

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "students",
    indices = [Index(value = ["studentNumber", "year", "level", "subject", "groupName"], unique = true)]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val studentNumber: String,
    val phone: String = "",
    val year: String,
    val level: String,
    val subject: String,
    val groupName: String,
    val workTitle: String = "",
    val notes: String = ""
)

@Entity(
    tableName = "attendance",
    indices = [Index(value = ["studentId", "date", "year", "level", "subject", "groupName"], unique = true)]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val studentName: String,
    val studentNumber: String,
    val date: String,
    val status: String,
    val year: String,
    val level: String,
    val subject: String,
    val groupName: String,
    val sessionTitle: String = ""
)

@Entity(tableName = "grades", indices = [Index(value = ["studentId"], unique = true)])
data class Grade(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val understanding: Double? = null,
    val coverage: Double? = null,
    val methodology: Double? = null,
    val participation: Double? = null,
    val exam: Double? = null,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val isComplete: Boolean get() = understanding != null && coverage != null &&
        methodology != null && participation != null && exam != null
    val total: Double? get() = if (isComplete) understanding!! + coverage!! + methodology!! + participation!! + exam!! else null
}

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY name COLLATE NOCASE")
    fun observeStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudent(id: Long): Student?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertStudent(student: Student): Long

    @Update
    suspend fun updateStudent(student: Student)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun deleteStudent(id: Long)

    @Query("SELECT * FROM attendance ORDER BY date DESC, studentName COLLATE NOCASE")
    fun observeAttendance(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE studentId = :studentId ORDER BY date DESC")
    suspend fun attendanceForStudent(studentId: Long): List<AttendanceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAttendance(records: List<AttendanceRecord>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAttendance(record: AttendanceRecord)

    @Query("SELECT * FROM grades ORDER BY studentId")
    fun observeGrades(): Flow<List<Grade>>

    @Query("SELECT * FROM grades WHERE studentId = :studentId LIMIT 1")
    suspend fun gradeForStudent(studentId: Long): Grade?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGrade(grade: Grade)

    @Query("SELECT * FROM students ORDER BY name COLLATE NOCASE")
    suspend fun allStudents(): List<Student>

    @Query("SELECT * FROM attendance ORDER BY date")
    suspend fun allAttendance(): List<AttendanceRecord>

    @Query("SELECT * FROM grades")
    suspend fun allGrades(): List<Grade>

    @Query("DELETE FROM attendance")
    suspend fun clearAttendance()

    @Query("DELETE FROM grades")
    suspend fun clearGrades()

    @Query("DELETE FROM students")
    suspend fun clearStudents()
}

@Database(entities = [Student::class, AttendanceRecord::class, Grade::class], version = 1, exportSchema = false)
abstract class StudentDatabase : RoomDatabase() {
    abstract fun dao(): StudentDao

    companion object {
        @Volatile private var INSTANCE: StudentDatabase? = null
        fun get(context: Context): StudentDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                StudentDatabase::class.java,
                "daftar_students.db"
            ).build().also { INSTANCE = it }
        }
    }
}
