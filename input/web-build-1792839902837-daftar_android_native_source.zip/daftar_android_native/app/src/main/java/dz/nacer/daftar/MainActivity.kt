package dz.nacer.daftar

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Teal = Color(0xFF176B67)
private val Ink = Color(0xFF18383B)
private val Pale = Color(0xFFE7F3F0)
private val Background = Color(0xFFF4F7F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(18, 60, 66)
        window.navigationBarColor = android.graphics.Color.rgb(18, 60, 66)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Ink, background = Background)) {
            DaftarApp()
        } }
    }
}

private enum class Page(val label: String) {
    HOME("الرئيسية"), STUDENTS("الطلبة"), ATTENDANCE("الحضور"), GRADES("التقييم"), REPORTS("التقارير")
}

@Composable
private fun DaftarApp() {
    val context = LocalContext.current
    val dao = remember { StudentDatabase.get(context).dao() }
    val scope = rememberCoroutineScope()
    val students by dao.observeStudents().collectAsStateWithLifecycle(emptyList())
    val attendance by dao.observeAttendance().collectAsStateWithLifecycle(emptyList())
    val grades by dao.observeGrades().collectAsStateWithLifecycle(emptyList())
    var page by remember { mutableStateOf(Page.HOME) }
    var search by remember { mutableStateOf("") }
    var selectedStudent by remember { mutableStateOf<Student?>(null) }
    var showStudentForm by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var attendanceDate by remember { mutableStateOf(today()) }
    var sessionTitle by remember { mutableStateOf("") }
    var filterYear by remember { mutableStateOf("2026–2027") }
    var filterLevel by remember { mutableStateOf("") }
    var filterSubject by remember { mutableStateOf("") }
    var filterGroup by remember { mutableStateOf("") }
    var statusDraft by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }
    var message by remember { mutableStateOf<String?>(null) }

    val filtered = students.filter { s ->
        (filterYear.isBlank() || s.year == filterYear) &&
        (filterLevel.isBlank() || s.level == filterLevel) &&
        (filterSubject.isBlank() || s.subject == filterSubject) &&
        (filterGroup.isBlank() || s.groupName == filterGroup) &&
        (search.isBlank() || s.name.contains(search, true) || s.studentNumber.contains(search, true) || s.workTitle.contains(search, true))
    }
    val years = students.map { it.year }.distinct().sorted()
    val levels = students.filter { filterYear.isBlank() || it.year == filterYear }.map { it.level }.distinct().sorted()
    val subjects = students.filter { (filterYear.isBlank() || it.year == filterYear) && (filterLevel.isBlank() || it.level == filterLevel) }.map { it.subject }.distinct().sorted()
    val groups = students.filter { (filterYear.isBlank() || it.year == filterYear) && (filterLevel.isBlank() || it.level == filterLevel) && (filterSubject.isBlank() || it.subject == filterSubject) }.map { it.groupName }.distinct().sorted()

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) scope.launch {
            runCatching {
                val json = JSONObject()
                json.put("version", 1)
                json.put("students", JSONArray(dao.allStudents().map { s -> JSONObject().apply {
                    put("id", s.id); put("name", s.name); put("studentNumber", s.studentNumber); put("phone", s.phone)
                    put("year", s.year); put("level", s.level); put("subject", s.subject); put("groupName", s.groupName)
                    put("workTitle", s.workTitle); put("notes", s.notes)
                } }))
                json.put("attendance", JSONArray(dao.allAttendance().map { a -> JSONObject().apply {
                    put("id", a.id); put("studentId", a.studentId); put("studentName", a.studentName); put("studentNumber", a.studentNumber)
                    put("date", a.date); put("status", a.status); put("year", a.year); put("level", a.level)
                    put("subject", a.subject); put("groupName", a.groupName); put("sessionTitle", a.sessionTitle)
                } }))
                json.put("grades", JSONArray(dao.allGrades().map { g -> JSONObject().apply {
                    put("id", g.id); put("studentId", g.studentId)
                    g.understanding?.let { put("understanding", it) }; g.coverage?.let { put("coverage", it) }
                    g.methodology?.let { put("methodology", it) }; g.participation?.let { put("participation", it) }
                    g.exam?.let { put("exam", it) }; put("updatedAt", g.updatedAt)
                } }))
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json.toString(2)) }
                message = "تم إنشاء النسخة الاحتياطية."
            }.onFailure { message = "تعذر إنشاء النسخة الاحتياطية: ${it.localizedMessage}" }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("تعذر قراءة الملف")
                val root = JSONObject(raw)
                val js = root.getJSONArray("students")
                val ja = root.getJSONArray("attendance")
                val jg = root.getJSONArray("grades")
                if (js.length() > 0 && !root.has("version")) error("نسخة احتياطية غير معروفة")
                android.app.AlertDialog.Builder(context).setTitle("تأكيد الاستعادة")
                    .setMessage("ستستبدل الاستعادة جميع البيانات الحالية. هل تريد المتابعة؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("استعادة") { _, _ ->
                        scope.launch {
                            runCatching {
                                dao.clearAttendance(); dao.clearGrades(); dao.clearStudents()
                                val ids = mutableMapOf<Long, Long>()
                                for (i in 0 until js.length()) {
                                    val o = js.getJSONObject(i)
                                    val oldId = o.optLong("id")
                                    val newId = dao.insertStudent(Student(
                                        name=o.getString("name"), studentNumber=o.getString("studentNumber"), phone=o.optString("phone"),
                                        year=o.getString("year"), level=o.getString("level"), subject=o.getString("subject"),
                                        groupName=o.getString("groupName"), workTitle=o.optString("workTitle"), notes=o.optString("notes")
                                    ))
                                    ids[oldId] = newId
                                }
                                for (i in 0 until ja.length()) {
                                    val o=ja.getJSONObject(i); val old=o.optLong("studentId"); val newId=ids[old] ?: continue
                                    dao.saveAttendance(AttendanceRecord(studentId=newId, studentName=o.optString("studentName"),
                                        studentNumber=o.optString("studentNumber"), date=o.getString("date"), status=o.getString("status"),
                                        year=o.getString("year"), level=o.getString("level"), subject=o.getString("subject"),
                                        groupName=o.getString("groupName"), sessionTitle=o.optString("sessionTitle")))
                                }
                                for (i in 0 until jg.length()) {
                                    val o=jg.getJSONObject(i); val newId=ids[o.optLong("studentId")] ?: continue
                                    dao.saveGrade(Grade(studentId=newId, understanding=if(o.has("understanding"))o.getDouble("understanding") else null,
                                        coverage=if(o.has("coverage"))o.getDouble("coverage") else null,
                                        methodology=if(o.has("methodology"))o.getDouble("methodology") else null,
                                        participation=if(o.has("participation"))o.getDouble("participation") else null,
                                        exam=if(o.has("exam"))o.getDouble("exam") else null, updatedAt=o.optLong("updatedAt", System.currentTimeMillis())))
                                }
                                message = "تمت استعادة النسخة الاحتياطية."
                            }.onFailure { message = "فشلت الاستعادة: ${it.localizedMessage}" }
                        }
                    }.show()
            }.onFailure { message = "الملف غير صالح أو لا يحتوي على بيانات النسخ الاحتياطي المطلوبة." }
        }
    }

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Image(painterResource(R.drawable.professor), null, Modifier.size(62.dp).background(Color.White, RoundedCornerShape(16.dp)))
                    Column {
                        Text("دفتر متابعة الطلبة", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("الأستاذ الدكتور ناصر يوسف", color = Color(0xFFD2E8E3), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Page.values().forEach { p ->
                        FilterChip(selected = page == p, onClick = { page = p }, label = { Text(p.label, maxLines = 1) })
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) },
        containerColor = Background
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (page != Page.HOME) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DropdownFilter("السنة", filterYear, (years + listOf("2026–2027")).distinct(), { filterYear = it; filterLevel = ""; filterSubject = ""; filterGroup = "" }, Modifier.weight(1f))
                        DropdownFilter("المستوى", filterLevel, levels, { filterLevel = it; filterSubject = ""; filterGroup = "" }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DropdownFilter("المقياس", filterSubject, subjects, { filterSubject = it; filterGroup = "" }, Modifier.weight(1f))
                        DropdownFilter("الفوج", filterGroup, groups, { filterGroup = it }, Modifier.weight(1f))
                    }
                }
            }
            when (page) {
                Page.HOME -> HomePage(students.size, filtered.size, attendance.count { it.status == "غائب" }, grades.count { it.total != null }, onGo = { page = it })
                Page.STUDENTS -> StudentsPage(filtered, search, { search = it }, { editingStudent = null; showStudentForm = true }, { selectedStudent = it })
                Page.ATTENDANCE -> AttendancePage(filtered, attendanceDate, { attendanceDate = it }, sessionTitle, { sessionTitle = it }, statusDraft, { statusDraft = it }, {
                    scope.launch {
                        val rows = filtered.mapNotNull { s ->
                            statusDraft[s.id]?.takeIf { it.isNotBlank() }?.let { st ->
                                AttendanceRecord(studentId=s.id, studentName=s.name, studentNumber=s.studentNumber,
                                    date=attendanceDate, status=st, year=s.year, level=s.level, subject=s.subject,
                                    groupName=s.groupName, sessionTitle=sessionTitle)
                            }
                        }
                        if (rows.isEmpty()) message = "حدد حالة طالب واحد على الأقل."
                        else {
                            dao.saveAttendance(rows)
                            message = "تم حفظ ${rows.size} سجل حضور."
                        }
                    }
                })
                Page.GRADES -> GradesPage(filtered, grades, { s ->
                    scope.launch {
                        val old = dao.gradeForStudent(s.id) ?: Grade(studentId=s.id)
                        editingStudent = s
                        selectedStudent = s
                    }
                }, dao)
                Page.REPORTS -> ReportsPage(onStudents = {
                    scope.launch { exportCsv(context, "students.csv", listOf("الاسم","الرقم الجامعي","الهاتف","السنة","المستوى","المقياس","الفوج","عنوان العمل","الملاحظات") + dao.allStudents().map { listOf(it.name,it.studentNumber,it.phone,it.year,it.level,it.subject,it.groupName,it.workTitle,it.notes) }) { message = it }
                }, onAttendance = {
                    scope.launch { exportCsv(context, "attendance.csv", listOf("الاسم","الرقم الجامعي","التاريخ","الحالة","المقياس","الفوج") + dao.allAttendance().map { listOf(it.studentName,it.studentNumber,it.date,it.status,it.subject,it.groupName) }) { message = it }
                }, onGrades = {
                    scope.launch {
                        val allS = dao.allStudents().associateBy { it.id }
                        val rows = dao.allGrades().map { g ->
                            val s = allS[g.studentId]
                            listOf(s?.name.orEmpty(), s?.studentNumber.orEmpty(), s?.workTitle.orEmpty(),
                                g.understanding?.toString().orEmpty(),g.coverage?.toString().orEmpty(),g.methodology?.toString().orEmpty(),
                                g.participation?.toString().orEmpty(),g.exam?.toString().orEmpty(),g.total?.toString() ?: "غير مكتمل")
                        }
                        exportCsv(context, "grades.csv", listOf("الاسم","الرقم الجامعي","عنوان العمل","الفهم /6","التغطية /3","المنهجية /3","المواظبة /2","الاختبار /6","المجموع /20") + rows) { message = it }
                    }
                }, onBackup = { backupLauncher.launch("daftar-backup.json") }, onRestore = { restoreLauncher.launch(arrayOf("application/json", "text/*")) })
            }
        }
    }

    if (showStudentForm) {
        StudentEditor(
            initial = editingStudent,
            onDismiss = { showStudentForm = false },
            onSave = { s ->
                scope.launch {
                    runCatching {
                        if (s.id == 0L) dao.insertStudent(s) else dao.updateStudent(s)
                        showStudentForm = false
                        message = "تم حفظ بيانات الطالب."
                    }.onFailure { message = "تعذر الحفظ. تحقق من عدم تكرار الرقم الجامعي في السياق نفسه." }
                }
            }
        )
    }
    selectedStudent?.let { s ->
        StudentDetails(s, attendance.filter { it.studentId == s.id }, grades.firstOrNull { it.studentId == s.id },
            onDismiss = { selectedStudent = null },
            onEdit = { editingStudent = s; selectedStudent = null; showStudentForm = true },
            onDelete = {
                scope.launch { dao.deleteStudent(s.id); selectedStudent = null; message = "تم حذف الطالب." }
            },
            onGrade = { page = Page.GRADES; selectedStudent = null }
        )
    }
    message?.let { msg ->
        AlertDialog(onDismissRequest = { message = null }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } },
            title = { Text("دفتر متابعة الطلبة") }, text = { Text(msg) })
    }
}

@Composable
private fun DropdownFilter(label: String, value: String, options: List<String>, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${value.ifBlank { "الكل" }}", maxLines = 1, overflow = TextOverflow.Ellipsis)
            Icon(Icons.Default.ArrowDropDown, null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("الكل") }, onClick = { onSelect(""); expanded = false })
            options.forEach { opt -> DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(opt); expanded = false }) }
        }
    }
}

@Composable
private fun HomePage(total: Int, filtered: Int, absences: Int, completeGrades: Int, onGo: (Page) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("لوحة التحكم", style = MaterialTheme.typography.headlineSmall, color = Ink, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("إجمالي الطلبة", total.toString(), Modifier.weight(1f))
            StatCard("ضمن التصفية", filtered.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("حالات الغياب", absences.toString(), Modifier.weight(1f))
            StatCard("تقييمات مكتملة", completeGrades.toString(), Modifier.weight(1f))
        }
        Text("اختصارات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        listOf(Page.STUDENTS, Page.ATTENDANCE, Page.GRADES, Page.REPORTS).forEach { p ->
            Card(Modifier.fillMaxWidth().clickable { onGo(p) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(when(p){Page.STUDENTS->Icons.Default.People;Page.ATTENDANCE->Icons.Default.EventAvailable;Page.GRADES->Icons.Default.School;else->Icons.Default.FileDownload}, null, tint = Teal)
                    Spacer(Modifier.width(12.dp)); Text(p.label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronLeft, null)
                }
            }
        }
        Text("تُحفظ البيانات محليًا على الجهاز باستخدام قاعدة بيانات Room. صدّر نسخة احتياطية دوريًا.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Teal, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}

@Composable
private fun StudentsPage(
    students: List<Student>, search: String, onSearch: (String) -> Unit,
    onAdd: () -> Unit, onOpen: (Student) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth(), label = { Text("بحث بالاسم أو الرقم أو عنوان العمل") }, singleLine = true)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.End) {
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("إضافة طالب") }
        }
        if (students.isEmpty()) EmptyState("لا توجد بيانات طلبة. أضف طالبًا للبدء.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(students, key = { it.id }) { s ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(s) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(s.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("الرقم الجامعي: ${s.studentNumber}", color = Color.Gray)
                        Text("${s.year} · ${s.level} · ${s.subject} · ${s.groupName}", style = MaterialTheme.typography.bodySmall)
                        Text("الهاتف: ${s.phone.ifBlank { "غير مسجل" }}", style = MaterialTheme.typography.bodySmall)
                        Text("عنوان العمل: ${s.workTitle.ifBlank { "غير محدد" }}", style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun StudentEditor(initial: Student?, onDismiss: () -> Unit, onSave: (Student) -> Unit) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var number by remember { mutableStateOf(initial?.studentNumber.orEmpty()) }
    var phone by remember { mutableStateOf(initial?.phone.orEmpty()) }
    var year by remember { mutableStateOf(initial?.year ?: "2026–2027") }
    var level by remember { mutableStateOf(initial?.level.orEmpty()) }
    var subject by remember { mutableStateOf(initial?.subject.orEmpty()) }
    var group by remember { mutableStateOf(initial?.groupName.orEmpty()) }
    var work by remember { mutableStateOf(initial?.workTitle.orEmpty()) }
    var notes by remember { mutableStateOf(initial?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة طالب" else "تعديل بيانات الطالب") },
        text = {
            Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EditorField("الاسم الكامل *", name, { name = it })
                EditorField("الرقم الجامعي *", number, { number = it })
                EditorField("رقم الهاتف (اختياري)", phone, { phone = it })
                EditorField("السنة الجامعية *", year, { year = it })
                EditorField("المستوى الدراسي *", level, { level = it })
                EditorField("المقياس / المادة *", subject, { subject = it })
                EditorField("الفوج / المجموعة *", group, { group = it })
                EditorField("عنوان العمل المكلّف به", work, { work = it }, singleLine = false)
                EditorField("ملاحظات الأستاذ", notes, { notes = it }, singleLine = false)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { Button(onClick = {
            if (listOf(name, number, year, level, subject, group).any { it.isBlank() }) {
                error = "يرجى ملء الحقول الأساسية المشار إليها بعلامة *."
            } else {
                onSave(Student(id=initial?.id ?: 0, name=name.trim(), studentNumber=number.trim(), phone=phone.trim(),
                    year=year.trim(), level=level.trim(), subject=subject.trim(), groupName=group.trim(), workTitle=work.trim(), notes=notes.trim()))
            }
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun EditorField(label: String, value: String, onValue: (String) -> Unit, singleLine: Boolean = true) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = singleLine)
}

@Composable
private fun AttendancePage(
    students: List<Student>, date: String, onDate: (String) -> Unit,
    title: String, onTitle: (String) -> Unit, draft: Map<Long, String>,
    onDraft: (Map<Long, String>) -> Unit, onSave: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(date, onDate, Modifier.fillMaxWidth(), label = { Text("تاريخ الحصة (YYYY-MM-DD)") }, singleLine = true)
        OutlinedTextField(title, onTitle, Modifier.fillMaxWidth(), label = { Text("عنوان الحصة (اختياري)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            listOf("حاضر", "غائب", "متأخر").forEach { status ->
                OutlinedButton(onClick = { onDraft(students.associate { it.id to status }) }, modifier = Modifier.weight(1f)) { Text("الجميع $status", maxLines = 1) }
            }
        }
        if (students.isEmpty()) EmptyState("أضف طلبة وحدد السياق الأكاديمي أولًا.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(students, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(s.name, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf("لم يسجل", "حاضر", "غائب", "متأخر").forEach { status ->
                                val value = if (status == "لم يسجل") "" else status
                                FilterChip(selected = (draft[s.id] ?: "") == value, onClick = {
                                    onDraft(draft.toMutableMap().apply { if (value.isBlank()) remove(s.id) else put(s.id, value) })
                                }, label = { Text(status) })
                            }
                        }
                    }
                }
            }
        }
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) { Text("حفظ سجل الحصة") }
    }
}

@Composable
private fun GradesPage(students: List<Student>, grades: List<Grade>, onSelect: (Student) -> Unit, dao: StudentDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<Student?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("شبكة التقييم من 20", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("الشرح والفهم 6 · تغطية الموضوع 3 · المنهجية 3 · المواظبة 2 · الاختبار الكتابي 6", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 10.dp, bottom = 20.dp)) {
            items(students, key = { it.id }) { s ->
                val g = grades.firstOrNull { it.studentId == s.id }
                Card(Modifier.fillMaxWidth().clickable { editing = s }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold)
                            Text("المجموع: ${g?.total?.let { "%.2f".format(Locale.ROOT, it) + " / 20" } ?: "غير مكتمل"}", color = Teal)
                        }
                        Icon(Icons.Default.Edit, null, tint = Teal)
                    }
                }
            }
        }
    }
    editing?.let { s ->
        val old = grades.firstOrNull { it.studentId == s.id }
        GradeEditor(s, old, onDismiss = { editing = null }, onSave = { g ->
            scope.launch {
                runCatching { dao.saveGrade(g); editing = null }
                    .onFailure { Toast.makeText(context, "تعذر حفظ العلامة", Toast.LENGTH_SHORT).show() }
            }
        })
    }
}

@Composable
private fun GradeEditor(student: Student, old: Grade?, onDismiss: () -> Unit, onSave: (Grade) -> Unit) {
    val rubric = listOf("الشرح والفهم" to (6.0 to (old?.understanding)), "تغطية الموضوع" to (3.0 to old?.coverage),
        "المنهجية العلمية" to (3.0 to old?.methodology), "المواظبة" to (2.0 to old?.participation), "الاختبار الكتابي" to (6.0 to old?.exam))
    var values by remember { mutableStateOf(listOf(old?.understanding, old?.coverage, old?.methodology, old?.participation, old?.exam).map { it?.toString().orEmpty() }) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تقييم ${student.name}") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rubric.forEachIndexed { index, item ->
                    OutlinedTextField(values[index], { v -> values = values.toMutableList().also { it[index] = v } },
                        Modifier.fillMaxWidth(), label = { Text("${item.first} (من ${item.second.first.toInt()})") }, singleLine = true)
                }
                val nums = values.map { it.toDoubleOrNull() }
                val complete = nums.all { it != null }
                val total = if (complete) nums.filterNotNull().sum() else null
                Text("المجموع: ${total?.let { "%.2f".format(Locale.ROOT, it) } ?: "غير مكتمل"} / 20", color = Teal, fontWeight = FontWeight.Bold)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { Button(onClick = {
            val maxima = listOf(6.0,3.0,3.0,2.0,6.0)
            for (i in values.indices) {
                val raw = values[i].trim()
                if (raw.isNotEmpty()) {
                    val n = raw.toDoubleOrNull()
                    if (n == null || n < 0 || n > maxima[i]) { error = "تحقق من العلامات؛ الحد الأقصى لكل معيار ظاهر بجواره."; return@Button }
                }
            }
            onSave(Grade(studentId=student.id, understanding=values[0].toDoubleOrNull(), coverage=values[1].toDoubleOrNull(),
                methodology=values[2].toDoubleOrNull(), participation=values[3].toDoubleOrNull(), exam=values[4].toDoubleOrNull()))
        }) { Text("حفظ العلامات") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun StudentDetails(student: Student, records: List<AttendanceRecord>, grade: Grade?, onDismiss: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit, onGrade: () -> Unit) {
    val present = records.count { it.status == "حاضر" }
    val absent = records.count { it.status == "غائب" }
    val late = records.count { it.status == "متأخر" }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(student.name) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("الرقم الجامعي: ${student.studentNumber}")
                Text("الهاتف: ${student.phone.ifBlank { "غير مسجل" }}")
                Text("${student.year} · ${student.level} · ${student.subject} · ${student.groupName}")
                Text("عنوان العمل: ${student.workTitle.ifBlank { "غير محدد" }}")
                Text("ملاحظات: ${student.notes.ifBlank { "لا توجد" }}")
                Divider()
                Text("الحضور: ${records.size} حصة · حاضر $present · غائب $absent · متأخر $late")
                Text("نسبة الحضور: ${if (records.isEmpty()) "لا توجد حصص" else "${(present * 100 / records.size)}%"}")
                Text("تواريخ الغياب: ${records.filter { it.status == "غائب" }.joinToString("، ") { it.date }.ifBlank { "لا يوجد" }}")
                Divider()
                Text("التقييم: ${grade?.total?.let { "%.2f".format(Locale.ROOT, it) + " / 20" } ?: "غير مكتمل"}")
                Text("الشرح ${grade?.understanding ?: "—"}/6 · التغطية ${grade?.coverage ?: "—"}/3 · المنهجية ${grade?.methodology ?: "—"}/3 · المواظبة ${grade?.participation ?: "—"}/2 · الاختبار ${grade?.exam ?: "—"}/6", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = onEdit) { Text("تعديل") } },
        dismissButton = { Row {
            TextButton(onClick = onGrade) { Text("التقييم") }
            TextButton(onClick = onDismiss) { Text("إغلاق") }
            TextButton(onClick = onDelete) { Text("حذف") }
        } }
    )
}

@Composable
private fun ReportsPage(onStudents: () -> Unit, onAttendance: () -> Unit, onGrades: () -> Unit, onBackup: () -> Unit, onRestore: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("التقارير والنسخ الاحتياطي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Button(onClick = onStudents, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Text("تصدير قائمة الطلبة CSV") }
        Button(onClick = onAttendance, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Text("تصدير الحضور والغياب CSV") }
        Button(onClick = onGrades, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Text("تصدير العلامات CSV") }
        OutlinedButton(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Text("إنشاء نسخة احتياطية JSON") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Text("استعادة نسخة احتياطية JSON") }
        Text("البيانات محفوظة محليًا على الجهاز في قاعدة Room. لا تتم مزامنتها أو إرسالها إلى خدمة خارجية.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { Text(text, color = Color.Gray) }
}

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())

private suspend fun exportCsv(context: android.content.Context, filename: String, rows: List<List<String>>, done: (String) -> Unit) {
    runCatching {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("تعذر إنشاء ملف التصدير")
        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { out ->
            out.write("\uFEFF")
            rows.forEach { row ->
                out.write(row.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                out.write("\r\n")
            }
        } ?: error("تعذر كتابة الملف")
        done("تم تصدير الملف إلى مجلد Downloads: $filename")
    }.onFailure { done("تعذر التصدير: ${it.localizedMessage}") }
}
