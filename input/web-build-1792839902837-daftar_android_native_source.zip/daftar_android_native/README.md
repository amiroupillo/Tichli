# دفتر متابعة الطلبة — مشروع Android أصلي

مشروع Android Studio باستخدام Kotlin + Jetpack Compose + Room.

## إصلاح توافق JVM
في `app/build.gradle.kts` تم ضبط:
- `sourceCompatibility = JavaVersion.VERSION_17`
- `targetCompatibility = JavaVersion.VERSION_17`
- `kotlinOptions { jvmTarget = "17" }`

وهذا يعالج التعارض المذكور في السجل:
`compileDebugJavaWithJavac (1.8)` مقابل `compileDebugKotlin (17)`.

## فتح وبناء المشروع
1. فك ضغط الملف.
2. افتح مجلد `daftar_android_native` في Android Studio.
3. استخدم JDK 17 لمشروع Gradle (Settings > Build Tools > Gradle > Gradle JDK).
4. اسمح بمزامنة Gradle ثم Build > Build APK(s).
5. ملف APK عادة يظهر في `app/build/outputs/apk/debug/app-debug.apk`.

إعدادات البناء:
- Android Gradle Plugin 8.7.3
- Gradle 8.9 متوافق مع AGP 8.7.x
- Kotlin Android plugin 2.0.21
- Java/Kotlin JVM target 17
- compileSdk 35، minSdk 26

## الوظائف الموجودة في هذه النسخة
- واجهة عربية RTL وصورة الأستاذ المرفقة.
- Room database محلية.
- إضافة وتعديل وحذف الطلبة مع تحقق من الحقول الأساسية وتفرد الرقم الجامعي ضمن السياق الأكاديمي.
- رقم الهاتف وعنوان العمل والملاحظات.
- بحث وترشيح السنة والمستوى والمقياس والفوج.
- تسجيل حالات الحضور والغياب والتأخر وتاريخ الحصة.
- تقييمات من خمسة معايير /20، مع التمييز بين الحقل الفارغ والصفر والتحقق من الحدود.
- ملف طالب مع ملخص الحضور والغياب والتقييم.
- تصدير CSV إلى Downloads.
- نسخ احتياطي JSON واستعادة مع تأكيد.

## حدود معروفة
- لم يتم إنتاج APK من بيئة المحادثة، ولم يتم تشغيل بناء Android فعلي هنا؛ يجب التحقق من البناء في Android Studio أو CI.
- الاستعادة تدعم ملف النسخ الاحتياطي JSON الذي ينشئه هذا التطبيق؛ اختبرها أولًا على نسخة تجريبية.
- تصدير CSV إلى Downloads يستخدم MediaStore على Android 10+.
- لم تُنفذ بعد ميزة تعديل/حذف سجل حضور فردي من الواجهة، ولا تقرير PDF أصلي.
- استيراد XLSX/CSV إلى قاعدة البيانات غير مدمج في هذه النسخة.
- إذا أظهر AndroidForge خطأ جديدًا، أرسل السجل الجديد حتى يمكن تصحيحه.
