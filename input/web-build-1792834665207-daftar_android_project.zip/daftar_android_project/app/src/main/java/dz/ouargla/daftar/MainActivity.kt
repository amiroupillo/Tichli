package dz.ouargla.daftar

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val createFileRequest = 701
    private val openFileRequest = 702
    private val htmlFileRequest = 703
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBytes: ByteArray? = null
    private var pendingMime = "application/octet-stream"
    private var pendingName = "export.txt"
    private var pendingJs: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "application/json", "text/plain"))
                }
                return try { startActivityForResult(intent, htmlFileRequest); true }
                catch (e: Exception) { filePathCallback = null; false }
            }
        }
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun saveFile(name: String, mime: String, content: String) {
            runOnUiThread {
                pendingName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "export.txt" }
                pendingMime = mime.ifBlank { "application/octet-stream" }
                pendingBytes = content.toByteArray(Charsets.UTF_8)
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = pendingMime
                    putExtra(Intent.EXTRA_TITLE, pendingName)
                }
                startActivityForResult(intent, createFileRequest)
            }
        }
        @JavascriptInterface fun openFile(accept: String) {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "application/json", "text/plain"))
                }
                startActivityForResult(intent, openFileRequest)
            }
        }
    }

    @Deprecated("Deprecated in Android API but widely supported")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == htmlFileRequest) {
            filePathCallback?.onReceiveValue(if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null)
            filePathCallback = null
            return
        }
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        try {
            if (requestCode == createFileRequest) {
                contentResolver.openOutputStream(uri)?.use { it.write(pendingBytes ?: byteArrayOf()) }
                Toast.makeText(this, "تم حفظ الملف", Toast.LENGTH_SHORT).show()
                pendingBytes = null
            } else if (requestCode == openFileRequest) {
                val content = contentResolver.openInputStream(uri)?.use { input ->
                    val out = ByteArrayOutputStream(); input.copyTo(out); out.toByteArray().toString(Charsets.UTF_8)
                } ?: ""
                val escaped = org.json.JSONObject.quote(content)
                web.evaluateJavascript("window.__androidImportedText = $escaped; window.dispatchEvent(new Event('android-file-picked'));", null)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر التعامل مع الملف", Toast.LENGTH_LONG).show()
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
