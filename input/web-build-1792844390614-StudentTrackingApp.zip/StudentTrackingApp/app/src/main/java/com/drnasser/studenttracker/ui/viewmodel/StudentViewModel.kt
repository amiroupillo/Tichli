package com.drnasser.studenttracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.drnasser.studenttracker.data.model.*
import com.drnasser.studenttracker.data.repository.StudentRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class StudentViewModel(private val repository: StudentRepository) : ViewModel() {

    val students: StateFlow<List<Student>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessions: StateFlow<List<Session>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val evaluations: StateFlow<List<Evaluation>> = repository.allEvaluations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedYear = MutableStateFlow<String?>(null)
    val selectedYear = _selectedYear.asStateFlow()

    private val _selectedGroup = MutableStateFlow<String?>(null)
    val selectedGroup = _selectedGroup.asStateFlow()

    val filteredStudents: StateFlow<List<Student>> = combine(
        students, _searchQuery, _selectedYear, _selectedGroup
    ) { list, query, year, group ->
        list.filter { student ->
            val matchesQuery = query.isBlank() ||
                    student.fullName.contains(query, ignoreCase = true) ||
                    student.studentIdNumber.contains(query, ignoreCase = true) ||
                    student.researchTopic.contains(query, ignoreCase = true)
            
            val matchesYear = year == null || student.academicYear == year
            val matchesGroup = group == null || student.group == group

            matchesQuery && matchesYear && matchesGroup
        }.sortedBy { it.fullName }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterYear(year: String?) {
        _selectedYear.value = year
    }

    fun setFilterGroup(group: String?) {
        _selectedGroup.value = group
    }

    fun clearFilters() {
        _searchQuery.value = ""
        _selectedYear.value = null
        _selectedGroup.value = null
    }

    fun insertStudent(student: Student, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val existing = repository.getStudentByIdNumber(student.studentIdNumber)
            if (existing != null) {
                onError("الرقم الجامعي ${student.studentIdNumber} موجود بالفعل لطالب آخر!")
            } else {
                repository.insertStudent(student)
                onSuccess()
            }
        }
    }

    fun updateStudent(student: Student, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.updateStudent(student)
            onSuccess()
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
        }
    }

    fun createSession(subject: String, group: String, date: String, title: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.createSession(Session(subject = subject, group = group, date = date, title = title))
            onCreated(id)
        }
    }

    fun saveAttendance(record: AttendanceRecord) {
        viewModelScope.launch {
            repository.recordAttendance(record)
        }
    }

    fun saveEvaluation(evaluation: Evaluation) {
        viewModelScope.launch {
            repository.saveEvaluation(evaluation)
        }
    }

    fun restoreBackup(backupData: BackupData, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.restoreAllData(backupData)
            onSuccess()
        }
    }
}
