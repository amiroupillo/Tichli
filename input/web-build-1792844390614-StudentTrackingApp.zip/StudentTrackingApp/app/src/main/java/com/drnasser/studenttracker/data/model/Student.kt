package com.drnasser.studenttracker.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "students",
    indices = [Index(value = ["studentIdNumber"], unique = true)]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentIdNumber: String,
    val fullName: String,
    val phone: String,
    val academicYear: String,
    val level: String,
    val subject: String,
    val group: String,
    val researchTopic: String,
    val notes: String = ""
)
