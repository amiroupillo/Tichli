package com.drnasser.studenttracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.drnasser.studenttracker.data.model.AttendanceRecord
import com.drnasser.studenttracker.ui.viewmodel.StudentViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: StudentViewModel,
    onBack: () -> Unit
) {
    val students by viewModel.students.collectAsState()
    val sessions by viewModel.sessions.collectAsState()

    var selectedSessionId by remember { mutableStateOf<Long?>(null) }
    var sessionTitle by remember { mutableStateOf("حصة جديدة") }
    var subject by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("فوج 1") }
    val currentDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تسجيل الحضور والغياب") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("إنشاء حصة أو اختيار حصة مسجلة", style = MaterialTheme.typography.titleMedium)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("المقياس") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = group,
                    onValueChange = { group = it },
                    label = { Text("الفوج") },
                    modifier = Modifier.weight(1f)
                )
            }

            Button(
                onClick = {
                    if (subject.isNotBlank()) {
                        viewModel.createSession(
                            subject = subject,
                            group = group,
                            date = currentDate,
                            title = sessionTitle
                        ) { id -> selectedSessionId = id }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("بدء تسجيل الحصة اليوم ($currentDate)")
            }

            Divider()

            Text("قائمة الطلبة وتسجيل الحالة:", style = MaterialTheme.typography.titleMedium)

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(students) { student ->
                    var status by remember { mutableStateOf("حاضر") }
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(student.fullName, style = MaterialTheme.typography.bodyLarge)
                                Text("الرقم: ${student.studentIdNumber}", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                FilterChip(
                                    selected = status == "حاضر",
                                    onClick = {
                                        status = "حاضر"
                                        selectedSessionId?.let { sId ->
                                            viewModel.saveAttendance(AttendanceRecord(sessionId = sId, studentId = student.id, status = "حاضر"))
                                        }
                                    },
                                    label = { Text("حاضر") }
                                )
                                FilterChip(
                                    selected = status == "غائب",
                                    onClick = {
                                        status = "غائب"
                                        selectedSessionId?.let { sId ->
                                            viewModel.saveAttendance(AttendanceRecord(sessionId = sId, studentId = student.id, status = "غائب"))
                                        }
                                    },
                                    label = { Text("غائب") }
                                )
                                FilterChip(
                                    selected = status == "متأخر",
                                    onClick = {
                                        status = "متأخر"
                                        selectedSessionId?.let { sId ->
                                            viewModel.saveAttendance(AttendanceRecord(sessionId = sId, studentId = student.id, status = "متأخر"))
                                        }
                                    },
                                    label = { Text("متأخر") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
