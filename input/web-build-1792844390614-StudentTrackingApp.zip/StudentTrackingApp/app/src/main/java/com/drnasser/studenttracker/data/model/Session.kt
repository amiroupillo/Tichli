package com.drnasser.studenttracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sessions")
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val group: String,
    val date: String,
    val title: String
)
