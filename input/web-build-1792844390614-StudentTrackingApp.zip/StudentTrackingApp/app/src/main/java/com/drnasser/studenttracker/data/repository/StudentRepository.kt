package com.drnasser.studenttracker.data.repository

import com.drnasser.studenttracker.data.local.*
import com.drnasser.studenttracker.data.model.*
import kotlinx.coroutines.flow.Flow

class StudentRepository(
    private val studentDao: StudentDao,
    private val sessionDao: SessionDao,
    private val attendanceDao: AttendanceDao,
    private val evaluationDao: EvaluationDao
) {
    val allStudents: Flow<List<Student>> = studentDao.getAllStudents()
    val allSessions: Flow<List<Session>> = sessionDao.getAllSessions()
    val allEvaluations: Flow<List<Evaluation>> = evaluationDao.getAllEvaluations()

    suspend fun getStudentById(id: Long): Student? = studentDao.getStudentById(id)
    suspend fun getStudentByIdNumber(idNum: String): Student? = studentDao.getStudentByIdNumber(idNum)

    suspend fun insertStudent(student: Student): Long = studentDao.insertStudent(student)
    suspend fun updateStudent(student: Student) = studentDao.updateStudent(student)
    suspend fun deleteStudent(student: Student) = studentDao.deleteStudent(student)

    suspend fun createSession(session: Session): Long = sessionDao.insertSession(session)

    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForStudent(studentId)

    fun getAttendanceForSession(sessionId: Long): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForSession(sessionId)

    suspend fun recordAttendance(record: AttendanceRecord) =
        attendanceDao.insertOrUpdateAttendance(record)

    fun getEvaluationForStudent(studentId: Long): Flow<Evaluation?> =
        evaluationDao.getEvaluationForStudent(studentId)

    suspend fun saveEvaluation(evaluation: Evaluation) =
        evaluationDao.insertOrUpdateEvaluation(evaluation)

    suspend fun restoreAllData(backupData: BackupData) {
        studentDao.deleteAllStudents()
        sessionDao.deleteAllSessions()
        attendanceDao.deleteAllAttendance()
        evaluationDao.deleteAllEvaluations()

        for (student in backupData.students) {
            studentDao.insertStudent(student)
        }
        for (session in backupData.sessions) {
            sessionDao.insertSession(session)
        }
        attendanceDao.insertAll(backupData.attendanceRecords)
        evaluationDao.insertAll(backupData.evaluations)
    }
}
