package com.drnasser.studenttracker.util

import com.drnasser.studenttracker.data.model.Evaluation
import com.drnasser.studenttracker.data.model.Student
import java.io.OutputStream

object CsvExporter {

    private val UTF8_BOM = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())

    fun exportStudentsToCsv(outputStream: OutputStream, students: List<Student>) {
        outputStream.write(UTF8_BOM)
        val writer = outputStream.bufferedWriter(Charsets.UTF_8)
        
        writer.write("الرقم الجامعي,الاسم الكامل,رقم الهاتف,السنة الجامعية,المستوى الدراسي,المقياس,الفوج,موضوع البحث,ملاحظات الأستاذ\n")
        
        for (student in students) {
            val line = listOf(
                escapeCsv(student.studentIdNumber),
                escapeCsv(student.fullName),
                escapeCsv(student.phone),
                escapeCsv(student.academicYear),
                escapeCsv(student.level),
                escapeCsv(student.subject),
                escapeCsv(student.group),
                escapeCsv(student.researchTopic),
                escapeCsv(student.notes)
            ).joinToString(",")
            writer.write(line + "\n")
        }
        writer.flush()
    }

    fun exportEvaluationsToCsv(
        outputStream: OutputStream,
        students: List<Student>,
        evaluations: Map<Long, Evaluation>
    ) {
        outputStream.write(UTF8_BOM)
        val writer = outputStream.bufferedWriter(Charsets.UTF_8)
        
        writer.write("الرقم الجامعي,الاسم الكامل,الشرح والفهم (6),تغطية الموضوع (3),المنهجية العلمية (3),المواظبة (2),الاختبار الكتابي (6),المجموع (20),الحالة\n")
        
        for (student in students) {
            val eval = evaluations[student.id]
            val status = if (eval?.isComplete == true) "مكتمل" else "غير مكتمل"
            val totalStr = if (eval?.isComplete == true) String.format("%.2f", eval.totalScore) else "غير مكتمل"
            
            val line = listOf(
                escapeCsv(student.studentIdNumber),
                escapeCsv(student.fullName),
                eval?.explanationUnderstanding?.toString() ?: "-",
                eval?.topicCoverage?.toString() ?: "-",
                eval?.scientificMethodology?.toString() ?: "-",
                eval?.attendancePunctuality?.toString() ?: "-",
                eval?.writtenExam?.toString() ?: "-",
                totalStr,
                status
            ).joinToString(",")
            writer.write(line + "\n")
        }
        writer.flush()
    }

    private fun escapeCsv(text: String): String {
        var escaped = text.replace(""", """")
        if (escaped.contains(",") || escaped.contains("\n") || escaped.contains(""")) {
            escaped = ""$escaped""
        }
        return escaped
    }
}
