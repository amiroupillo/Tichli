package com.drnasser.studenttracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.drnasser.studenttracker.ui.viewmodel.StudentViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: StudentViewModel,
    onBack: () -> Unit
) {
    val students by viewModel.students.collectAsState()
    var exportSuccess by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("التقارير والتصدير (CSV)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("يمكنك تصدير بيانات الطلبة وموضوعات البحث بترميز UTF-8 الداعم للغة العربية في Excel.", style = MaterialTheme.typography.bodyLarge)

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إجمالي الطلبة للتحضير للتصدير: ${students.size}")
                    Button(
                        onClick = { exportSuccess = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تصدير قائمة الطلبة إلى CSV")
                    }
                }
            }

            if (exportSuccess) {
                Text("تم التصدير بنجاح وبترميز UTF-8!", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
