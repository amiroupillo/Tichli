package com.drnasser.studenttracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.drnasser.studenttracker.ui.viewmodel.StudentViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: StudentViewModel,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("النسخ الاحتياطي والاستعادة") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("نظام النسخ الاحتياطي بصيغة JSON لحماية وقراءة كافة البيانات والعلاقات بين الطلبة والحضور والتقييمات.", style = MaterialTheme.typography.bodyLarge)

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { /* Export JSON */ }, modifier = Modifier.fillMaxWidth()) {
                        Text("إنشاء نسخة احتياطية (JSON)")
                    }
                    OutlinedButton(onClick = { /* Restore JSON */ }, modifier = Modifier.fillMaxWidth()) {
                        Text("استعادة نسخة احتياطية من ملف")
                    }
                }
            }
        }
    }
}
