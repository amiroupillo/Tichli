package com.drnasser.studenttracker.data.local

import androidx.room.*
import com.drnasser.studenttracker.data.model.Evaluation
import kotlinx.coroutines.flow.Flow

@Dao
interface EvaluationDao {
    @Query("SELECT * FROM evaluations WHERE studentId = :studentId")
    fun getEvaluationForStudent(studentId: Long): Flow<Evaluation?>

    @Query("SELECT * FROM evaluations")
    fun getAllEvaluations(): Flow<List<Evaluation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateEvaluation(evaluation: Evaluation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(evaluations: List<Evaluation>)

    @Query("DELETE FROM evaluations")
    suspend fun deleteAllEvaluations()
}
