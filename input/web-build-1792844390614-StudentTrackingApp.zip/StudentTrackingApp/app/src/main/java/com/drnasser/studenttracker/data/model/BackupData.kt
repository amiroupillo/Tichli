package com.drnasser.studenttracker.data.model

data class BackupData(
    val version: Int = 1,
    val exportDate: String,
    val students: List<Student>,
    val sessions: List<Session>,
    val attendanceRecords: List<AttendanceRecord>,
    val evaluations: List<Evaluation>
)
