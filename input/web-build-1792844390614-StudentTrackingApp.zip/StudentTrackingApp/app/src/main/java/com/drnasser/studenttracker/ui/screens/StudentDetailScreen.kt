package com.drnasser.studenttracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drnasser.studenttracker.ui.viewmodel.StudentViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDetailScreen(
    viewModel: StudentViewModel,
    studentId: Long,
    onBack: () -> Unit,
    onEditStudent: (Long) -> Unit
) {
    val students by viewModel.students.collectAsState()
    val student = students.find { it.id == studentId }
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog && student != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل أنت تأكد من حذف الطالب ${student.fullName} وكافة سجلات حضوره وتقييماته؟") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteStudent(student)
                    showDeleteDialog = false
                    onBack()
                }) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الملف التفصيلي للطالب") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    if (student != null) {
                        IconButton(onClick = { onEditStudent(student.id) }) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل")
                        }
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (student == null) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                Text("الطالب غير موجود!")
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = student.fullName, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(text = "الرقم الجامعي: ${student.studentIdNumber}", fontSize = 14.sp)
                        Text(text = "رقم الهاتف: ${student.phone.ifEmpty { "غير مدخل" }}", fontSize = 14.sp)
                        Text(text = "السنة الجامعية: ${student.academicYear}", fontSize = 14.sp)
                        Text(text = "المستوى الدراسي: ${student.level}", fontSize = 14.sp)
                        Text(text = "المقياس: ${student.subject}", fontSize = 14.sp)
                        Text(text = "الفوج: ${student.group}", fontSize = 14.sp)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "موضوع البحث", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = student.researchTopic, fontSize = 14.sp)
                    }
                }

                if (student.notes.isNotBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "ملاحظات الأستاذ", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = student.notes, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
