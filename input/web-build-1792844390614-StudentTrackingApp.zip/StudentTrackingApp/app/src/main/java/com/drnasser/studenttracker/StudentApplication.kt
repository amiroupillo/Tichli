package com.drnasser.studenttracker

import android.app.Application
import com.drnasser.studenttracker.data.local.AppDatabase
import com.drnasser.studenttracker.data.repository.StudentRepository

class StudentApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy {
        StudentRepository(
            database.studentDao(),
            database.sessionDao(),
            database.attendanceDao(),
            database.evaluationDao()
        )
    }
}
