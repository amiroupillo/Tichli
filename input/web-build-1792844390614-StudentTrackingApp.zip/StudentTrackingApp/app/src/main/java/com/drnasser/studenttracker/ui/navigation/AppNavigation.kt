package com.drnasser.studenttracker.ui.navigation

import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.drnasser.studenttracker.data.repository.StudentRepository
import com.drnasser.studenttracker.ui.screens.*
import com.drnasser.studenttracker.ui.viewmodel.StudentViewModel

@Composable
fun AppNavigation(repository: StudentRepository) {
    val navController = rememberNavController()
    val viewModel = remember { StudentViewModel(repository) }

    val students by viewModel.students.collectAsState()
    val sessions by viewModel.sessions.collectAsState()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                totalStudents = students.size,
                totalSessions = sessions.size,
                onNavigateToStudents = { navController.navigate("students") },
                onNavigateToAddStudent = { navController.navigate("add_student") },
                onNavigateToAttendance = { navController.navigate("attendance") },
                onNavigateToReports = { navController.navigate("reports") },
                onNavigateToBackup = { navController.navigate("backup") },
                onNavigateToAbout = { navController.navigate("about") }
            )
        }
        composable("students") {
            StudentListScreen(
                viewModel = viewModel,
                onAddStudentClick = { navController.navigate("add_student") },
                onStudentClick = { studentId -> navController.navigate("student_detail/$studentId") },
                onBack = { navController.popBackStack() }
            )
        }
        composable("add_student") {
            AddEditStudentScreen(
                viewModel = viewModel,
                studentId = null,
                onBack = { navController.popBackStack() }
            )
        }
        composable("student_detail/{studentId}") { backStackEntry ->
            val studentId = backStackEntry.arguments?.getString("studentId")?.toLongOrNull() ?: 0L
            StudentDetailScreen(
                viewModel = viewModel,
                studentId = studentId,
                onBack = { navController.popBackStack() },
                onEditStudent = { id -> navController.navigate("edit_student/$id") }
            )
        }
        composable("edit_student/{studentId}") { backStackEntry ->
            val studentId = backStackEntry.arguments?.getString("studentId")?.toLongOrNull() ?: 0L
            AddEditStudentScreen(
                viewModel = viewModel,
                studentId = studentId,
                onBack = { navController.popBackStack() }
            )
        }
        composable("attendance") {
            AttendanceScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("reports") {
            ReportsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("backup") {
            BackupRestoreScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("about") {
            AboutScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
