package com.drnasser.studenttracker.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drnasser.studenttracker.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("حول التطبيق") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.prof_nasser),
                contentDescription = "الأستاذ الدكتور ناصر يوسف",
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )

            Text("دفتر متابعة الطلبة", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("الأستاذ الدكتور ناصر يوسف", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
            Text("الإصدار: 1.0.0 (API 34 / Jetpack Compose)", fontSize = 13.sp)

            Spacer(modifier = Modifier.height(16.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("المميزات الرئيسية:", fontWeight = FontWeight.Bold)
                    Text("• يعمل 100% محلياً ودون إنترنت لحماية الخصوصية.")
                    Text("• إدارة دقيقة للطلبة مع اعتماد مصطلح «موضوع البحث».")
                    Text("• نظام تقييم متكامل من 20 بركائز علمية خمسة.")
                    Text("• إدارة الحضور والغياب مع تواريخ موثقة ورسم بياني للنسب.")
                    Text("• تصدير واستعادة البيانات بترميزات متوافقة مع Excel.")
                }
            }
        }
    }
}
