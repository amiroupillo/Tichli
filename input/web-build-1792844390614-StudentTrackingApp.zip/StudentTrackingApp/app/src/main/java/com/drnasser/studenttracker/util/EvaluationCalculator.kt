package com.drnasser.studenttracker.util

object EvaluationCalculator {
    const val MAX_EXPLANATION = 6.0f
    const val MAX_COVERAGE = 3.0f
    const val MAX_METHODOLOGY = 3.0f
    const val MAX_ATTENDANCE = 2.0f
    const val MAX_EXAM = 6.0f
    const val MAX_TOTAL = 20.0f

    fun validateCriteria(
        explanation: Float?,
        coverage: Float?,
        methodology: Float?,
        attendance: Float?,
        exam: Float?
    ): String? {
        if (explanation != null && (explanation < 0f || explanation > MAX_EXPLANATION)) return "علامة الشرح والفهم يجب أن تكون بين 0 و 6"
        if (coverage != null && (coverage < 0f || coverage > MAX_COVERAGE)) return "علامة تغطية الموضوع يجب أن تكون بين 0 و 3"
        if (methodology != null && (methodology < 0f || methodology > MAX_METHODOLOGY)) return "علامة المنهجية العلمية يجب أن تكون بين 0 و 3"
        if (attendance != null && (attendance < 0f || attendance > MAX_ATTENDANCE)) return "علامة المواظبة يجب أن تكون بين 0 و 2"
        if (exam != null && (exam < 0f || exam > MAX_EXAM)) return "علامة الاختبار الكتابي يجب أن تكون بين 0 و 6"
        return null
    }

    fun calculateAttendancePercentage(presentCount: Int, lateCount: Int, totalSessions: Int): Float {
        if (totalSessions <= 0) return 0f
        return ((presentCount + lateCount).toFloat() / totalSessions.toFloat()) * 100f
    }
}
