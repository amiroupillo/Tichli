package com.drnasser.studenttracker.data.local

import androidx.room.*
import com.drnasser.studenttracker.data.model.Session
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY date DESC")
    fun getAllSessions(): Flow<List<Session>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: Session): Long

    @Query("DELETE FROM sessions")
    suspend fun deleteAllSessions()
}
