package com.drnasser.studenttracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.drnasser.studenttracker.data.model.Student
import com.drnasser.studenttracker.ui.viewmodel.StudentViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditStudentScreen(
    viewModel: StudentViewModel,
    studentId: Long?,
    onBack: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var idNumber by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("2023/2024") }
    var level by remember { mutableStateOf("ليسانس 3") }
    var subject by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("فوج 1") }
    var researchTopic by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val students by viewModel.students.collectAsState()

    LaunchedEffect(studentId, students) {
        if (studentId != null) {
            val s = students.find { it.id == studentId }
            if (s != null) {
                fullName = s.fullName
                idNumber = s.studentIdNumber
                phone = s.phone
                year = s.academicYear
                level = s.level
                subject = s.subject
                group = s.group
                researchTopic = s.researchTopic
                notes = s.notes
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (studentId == null) "إضافة طالب جديد" else "تعديل بيانات الطالب") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (errorMessage != null) {
                Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("الاسم الكامل *") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = idNumber,
                onValueChange = { idNumber = it },
                label = { Text("الرقم الجامعي *") },
                modifier = Modifier.fillMaxWidth(),
                enabled = studentId == null
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("رقم الهاتف") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = year,
                onValueChange = { year = it },
                label = { Text("السنة الجامعية") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = level,
                onValueChange = { level = it },
                label = { Text("المستوى الدراسي") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it },
                label = { Text("المقياس *") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = group,
                onValueChange = { group = it },
                label = { Text("الفوج *") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = researchTopic,
                onValueChange = { researchTopic = it },
                label = { Text("موضوع البحث *") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("ملاحظات الأستاذ") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (fullName.isBlank() || idNumber.isBlank() || subject.isBlank() || group.isBlank() || researchTopic.isBlank()) {
                        errorMessage = "يرجى ملء جميع الحقول المطلوبة (*)"
                        return@Button
                    }
                    val student = Student(
                        id = studentId ?: 0L,
                        studentIdNumber = idNumber.trim(),
                        fullName = fullName.trim(),
                        phone = phone.trim(),
                        academicYear = year.trim(),
                        level = level.trim(),
                        subject = subject.trim(),
                        group = group.trim(),
                        researchTopic = researchTopic.trim(),
                        notes = notes.trim()
                    )
                    if (studentId == null) {
                        viewModel.insertStudent(
                            student = student,
                            onSuccess = { onBack() },
                            onError = { errorMessage = it }
                        )
                    } else {
                        viewModel.updateStudent(
                            student = student,
                            onSuccess = { onBack() }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (studentId == null) "حفظ الطالب" else "تحديث البيانات")
            }
        }
    }
}
