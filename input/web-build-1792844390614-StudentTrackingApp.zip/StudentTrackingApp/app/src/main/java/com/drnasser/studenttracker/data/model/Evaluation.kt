package com.drnasser.studenttracker.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "evaluations",
    foreignKeys = [
        ForeignKey(
            entity = Student::class,
            parentColumns = ["id"],
            childColumns = ["studentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["studentId"], unique = true)]
)
data class Evaluation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val explanationUnderstanding: Float? = null,
    val topicCoverage: Float? = null,
    val scientificMethodology: Float? = null,
    val attendancePunctuality: Float? = null,
    val writtenExam: Float? = null
) {
    val isComplete: Boolean
        get() = explanationUnderstanding != null &&
                topicCoverage != null &&
                scientificMethodology != null &&
                attendancePunctuality != null &&
                writtenExam != null

    val totalScore: Float
        get() = (explanationUnderstanding ?: 0f) +
                (topicCoverage ?: 0f) +
                (scientificMethodology ?: 0f) +
                (attendancePunctuality ?: 0f) +
                (writtenExam ?: 0f)
}
