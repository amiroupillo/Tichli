package com.drnasser.studenttracker.util

import com.drnasser.studenttracker.data.model.BackupData
import com.google.gson.Gson
import java.io.InputStream
import java.io.OutputStream

object JsonBackupHelper {
    private val gson = Gson()

    fun exportBackup(outputStream: OutputStream, backupData: BackupData) {
        val jsonString = gson.toJson(backupData)
        outputStream.write(jsonString.toByteArray(Charsets.UTF_8))
        outputStream.flush()
    }

    fun parseBackup(inputStream: InputStream): BackupData {
        val jsonString = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return gson.fromJson(jsonString, BackupData::class.java)
    }
}
