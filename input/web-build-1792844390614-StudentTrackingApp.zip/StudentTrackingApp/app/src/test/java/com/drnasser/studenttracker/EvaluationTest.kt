package com.drnasser.studenttracker

import com.drnasser.studenttracker.data.model.Evaluation
import com.drnasser.studenttracker.util.EvaluationCalculator
import org.junit.Assert.*
import org.junit.Test

class EvaluationTest {

    @Test
    fun testValidEvaluationTotal() {
        val eval = Evaluation(
            studentId = 1,
            explanationUnderstanding = 5.5f,
            topicCoverage = 2.5f,
            scientificMethodology = 2.5f,
            attendancePunctuality = 1.5f,
            writtenExam = 5.0f
        )
        assertTrue(eval.isComplete)
        assertEquals(17.0f, eval.totalScore, 0.01f)
    }

    @Test
    fun testIncompleteEvaluationHandling() {
        val eval = Evaluation(
            studentId = 1,
            explanationUnderstanding = 5.0f,
            topicCoverage = null,
            scientificMethodology = 2.0f,
            attendancePunctuality = 2.0f,
            writtenExam = 4.0f
        )
        assertFalse(eval.isComplete)
    }

    @Test
    fun testValidationLimits() {
        val error = EvaluationCalculator.validateCriteria(
            explanation = 7.0f,
            coverage = 2.0f,
            methodology = 2.0f,
            attendance = 1.0f,
            exam = 5.0f
        )
        assertNotNull(error)
        assertEquals("علامة الشرح والفهم يجب أن تكون بين 0 و 6", error)
    }

    @Test
    fun testAttendancePercentageZeroDivision() {
        val percentage = EvaluationCalculator.calculateAttendancePercentage(0, 0, 0)
        assertEquals(0.0f, percentage, 0.001f)
    }
}
