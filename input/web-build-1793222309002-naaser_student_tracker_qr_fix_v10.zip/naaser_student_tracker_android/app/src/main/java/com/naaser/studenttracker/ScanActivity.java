package com.naaser.studenttracker;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;

import java.util.Collections;
import java.util.List;

/** ماسح QR مستمر: يبقى مفتوحًا بعد كل مسح مع صوت تنبيه ورسالة باسم الطالب. */
public class ScanActivity extends Activity {
    private static final int REQ_CAMERA = 301;
    private DecoratedBarcodeView scanner;
    private TextView status, counter;
    private ToneGenerator tone;
    private String lastText;
    private long lastTime;
    private int okCount;
    private boolean ready;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            buildUi();
            try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100); } catch (Throwable ignored) { }
            ready = true;
        } catch (Throwable t) {
            android.util.Log.e("NaaserQR", "ScanActivity init failed", t);
            setResult(RESULT_FIRST_USER); // يطلب من MainActivity استخدام الماسح البديل
            finish();
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        scanner = new DecoratedBarcodeView(this);
        scanner.getBarcodeView().setDecoderFactory(
                new DefaultDecoderFactory(Collections.singletonList(BarcodeFormat.QR_CODE)));
        scanner.setStatusText("وجّه الكاميرا نحو بطاقة QR — الماسح يبقى مفتوحًا");
        root.addView(scanner, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xE6183C3A);
        panel.setPadding(32, 24, 32, 24);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(20);
        status.setGravity(Gravity.CENTER);
        status.setText("جاهز للمسح");
        panel.addView(status);

        counter = new TextView(this);
        counter.setTextColor(0xFFD9A441);
        counter.setTextSize(15);
        counter.setGravity(Gravity.CENTER);
        counter.setText("عدد الحاضرين في هذه الجلسة: 0");
        panel.addView(counter);

        Button done = new Button(this);
        done.setText("إنهاء المسح");
        done.setOnClickListener(v -> finish());
        panel.addView(done);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(panel, lp);
        setContentView(root);

        scanner.decodeContinuous(new BarcodeCallback() {
            @Override public void barcodeResult(BarcodeResult result) { onCode(result == null ? null : result.getText()); }
            @Override public void possibleResultPoints(List<ResultPoint> points) { }
        });
    }

    private void onCode(String text) {
        if (text == null || text.isEmpty()) return;
        long now = SystemClock.elapsedRealtime();
        if (text.equals(lastText) && now - lastTime < 2500) return; // تجاهل تكرار نفس الإطار
        lastText = text;
        lastTime = now;

        MainActivity main = MainActivity.instance;
        if (main == null) { show("bad", "تعذر الاتصال بالتطبيق"); return; }
        main.evaluateScan(text, value -> {
            String v = "";
            try {
                Object o = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                if (o instanceof String) v = (String) o;
            } catch (Throwable ignored) { }
            int i = v.indexOf('|');
            if (i < 0) show("bad", "رمز غير صالح");
            else show(v.substring(0, i), v.substring(i + 1));
        });
    }

    private void show(String kind, String message) {
        int toneType;
        String prefix;
        int color;
        if ("ok".equals(kind)) {
            okCount++;
            counter.setText("عدد الحاضرين في هذه الجلسة: " + okCount);
            toneType = ToneGenerator.TONE_PROP_BEEP; prefix = "✔ "; color = 0xFF8EF0B0;
        } else if ("dup".equals(kind)) {
            toneType = ToneGenerator.TONE_PROP_PROMPT; prefix = "↺ مسجّل مسبقًا: "; color = 0xFFFFD27A;
        } else {
            toneType = ToneGenerator.TONE_PROP_NACK; prefix = "✖ "; color = 0xFFFF9A9A;
        }
        status.setTextColor(color);
        status.setText(prefix + message);
        try { if (tone != null) tone.startTone(toneType, 250); } catch (Throwable ignored) { }
    }

    private void resumeScanner() {
        if (!ready) return;
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        scanner.resume();
    }

    @Override protected void onResume() { super.onResume(); resumeScanner(); }
    @Override protected void onPause() { super.onPause(); if (ready) scanner.pause(); }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) scanner.resume();
            else {
                Toast.makeText(this, "يلزم السماح باستخدام الكاميرا لمسح بطاقات QR.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tone != null) { try { tone.release(); } catch (Throwable ignored) { } }
        super.onDestroy();
    }
}
