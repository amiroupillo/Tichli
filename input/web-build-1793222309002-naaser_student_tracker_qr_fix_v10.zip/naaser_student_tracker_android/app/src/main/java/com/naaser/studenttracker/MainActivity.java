package com.naaser.studenttracker;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.Context;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.CaptureActivity;
import java.util.EnumMap;
import java.util.Map;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import android.content.ClipData;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.provider.MediaStore;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 201;
    private static final int SAVE_FILE_REQUEST = 202;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private byte[] pendingFileBytes;
    private String pendingMimeType = "application/octet-stream";
    private static final int QR_SCAN_REQUEST = IntentIntegrator.REQUEST_CODE;
    private static final int CAMERA_PERMISSION_REQUEST = 203;
    private boolean scanAfterPermission = false;
    private static final int SCAN_ACTIVITY_REQUEST = 204;
    static MainActivity instance;
    private static final int PHOTO_REQUEST = 205;
    private static final int CAMERA_PERMISSION_PHOTO = 206;
    private File pendingPhotoFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        installCrashLogger();
        showLastCrashIfAny();
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF2F5F3);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) || "about".equals(uri.getScheme())) return false;
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "text/csv", "text/comma-separated-values", "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/json", "text/plain"
                });
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException ex) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح مدير الملفات", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public String generateQr(String content) {
            try {
                BitMatrix matrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, 420, 420);
                Bitmap bitmap = Bitmap.createBitmap(420, 420, Bitmap.Config.ARGB_8888);
                for (int x = 0; x < 420; x++) for (int y = 0; y < 420; y++) bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                java.io.ByteArrayOutputStream stream = new java.io.ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                bitmap.recycle();
                return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void printHtml(String html) {
            runOnUiThread(() -> {
                try {
                    WebView printWebView = new WebView(MainActivity.this);
                    printWebView.getSettings().setJavaScriptEnabled(true);
                    printWebView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                            PrintDocumentAdapter adapter = view.createPrintDocumentAdapter("بطاقات_QR_الطلبة");
                            printManager.print("بطاقات QR للطلبة", adapter, new PrintAttributes.Builder().build());
                        }
                    });
                    printWebView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "تعذر فتح خدمة الطباعة على هذا الجهاز", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void captureStudentPhoto() {
            runOnUiThread(() -> beginPhotoCapture());
        }

        @JavascriptInterface
        public void startQrScan() {
            runOnUiThread(() -> beginQrScan());
        }

        @JavascriptInterface
        public void saveFile(String filename, String mimeType, String base64) {
            try {
                pendingFileBytes = Base64.decode(base64, Base64.DEFAULT);
                pendingMimeType = mimeType == null ? "application/octet-stream" : mimeType;
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingMimeType.contains("text/csv") ? "text/csv" :
                            (pendingMimeType.contains("json") ? "application/json" : pendingMimeType));
                    intent.putExtra(Intent.EXTRA_TITLE, filename);
                    try {
                        startActivityForResult(intent, SAVE_FILE_REQUEST);
                    } catch (ActivityNotFoundException ex) {
                        Toast.makeText(MainActivity.this, "لا يوجد تطبيق لحفظ الملفات", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذر تجهيز الملف للتصدير", Toast.LENGTH_LONG).show());
            }
        }
    }


    private void installCrashLogger() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringWriter sw = new StringWriter();
                throwable.printStackTrace(new PrintWriter(sw));
                try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "last_crash.txt"))) {
                    out.write(sw.toString().getBytes("UTF-8"));
                }
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }

    private void showLastCrashIfAny() {
        try {
            File f = new File(getFilesDir(), "last_crash.txt");
            if (!f.exists()) return;
            byte[] buf = new byte[(int) Math.min(f.length(), 6000)];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) { in.read(buf); }
            f.delete();
            android.widget.TextView tv = new android.widget.TextView(this);
            tv.setText(new String(buf, "UTF-8"));
            tv.setTextIsSelectable(true);
            tv.setTextSize(11);
            tv.setPadding(32, 16, 32, 16);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            new android.app.AlertDialog.Builder(this)
                    .setTitle("سبب الإغلاق السابق (أرسله للمطوّر)")
                    .setView(sv)
                    .setPositiveButton("حسنًا", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    private void deliverScanResult(String contents) {
        if (contents == null || webView == null) return;
        String escaped = org.json.JSONObject.quote(contents);
        webView.evaluateJavascript("window.handleScannedQr && window.handleScannedQr(" + escaped + ")", null);
    }

    private void beginPhotoCapture() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_PHOTO);
            return;
        }
        try {
            File dir = new File(getCacheDir(), "photos");
            if (!dir.exists()) dir.mkdirs();
            pendingPhotoFile = File.createTempFile("student_", ".jpg", dir);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pendingPhotoFile);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            intent.setClipData(ClipData.newRawUri("photo", uri));
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, PHOTO_REQUEST);
        } catch (Throwable ex) {
            android.util.Log.e("NaaserPhoto", "Unable to open camera", ex);
            Toast.makeText(this, "تعذر فتح الكاميرا لالتقاط الصورة", Toast.LENGTH_LONG).show();
        }
    }

    private void processCapturedPhoto() {
        final File f = pendingPhotoFile;
        pendingPhotoFile = null;
        if (f == null) return;
        new Thread(() -> {
            String dataUrl = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getAbsolutePath(), bounds);
                int sample = 1;
                while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 640) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                if (bmp != null) {
                    int orientation = new ExifInterface(f.getAbsolutePath())
                            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    float degrees = orientation == ExifInterface.ORIENTATION_ROTATE_90 ? 90f
                            : orientation == ExifInterface.ORIENTATION_ROTATE_180 ? 180f
                            : orientation == ExifInterface.ORIENTATION_ROTATE_270 ? 270f : 0f;
                    float scale = 360f / Math.max(bmp.getWidth(), bmp.getHeight());
                    if (scale > 1f) scale = 1f;
                    Matrix m = new Matrix();
                    m.postScale(scale, scale);
                    if (degrees != 0f) m.postRotate(degrees);
                    Bitmap out = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                    java.io.ByteArrayOutputStream stream = new java.io.ByteArrayOutputStream();
                    out.compress(Bitmap.CompressFormat.JPEG, 72, stream);
                    dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP);
                    if (out != bmp) out.recycle();
                    bmp.recycle();
                }
            } catch (Throwable ex) {
                android.util.Log.e("NaaserPhoto", "Unable to process photo", ex);
            } finally {
                f.delete();
            }
            final String result = dataUrl;
            runOnUiThread(() -> {
                if (result == null || webView == null) {
                    Toast.makeText(MainActivity.this, "تعذر معالجة الصورة", Toast.LENGTH_LONG).show();
                } else {
                    webView.evaluateJavascript("window.handleStudentPhoto && window.handleStudentPhoto("
                            + org.json.JSONObject.quote(result) + ")", null);
                }
            });
        }).start();
    }

    void evaluateScan(String contents, ValueCallback<String> cb) {
        if (webView == null) return;
        webView.evaluateJavascript("(window.handleScannedQr?window.handleScannedQr("
                + org.json.JSONObject.quote(contents) + "):'')", cb);
    }

    // الماسح الأساسي: ScanActivity (مسح مستمر). عند فشله يُستخدم Google Code Scanner ثم ZXing.
    private void beginQrScan() {
        try {
            startActivityForResult(new Intent(this, ScanActivity.class), SCAN_ACTIVITY_REQUEST);
        } catch (Throwable ex) {
            android.util.Log.e("NaaserQR", "ScanActivity failed", ex);
            beginGmsScan();
        }
    }

    private void beginGmsScan() {
        try {
            GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build();
            GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
            scanner.startScan()
                    .addOnSuccessListener(barcode -> deliverScanResult(barcode.getRawValue()))
                    .addOnCanceledListener(() ->
                            Toast.makeText(MainActivity.this, "تم إلغاء مسح QR", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> {
                        android.util.Log.e("NaaserQR", "Google scanner failed, using ZXing fallback", e);
                        beginZxingScan();
                    });
        } catch (Throwable ex) {
            android.util.Log.e("NaaserQR", "Google scanner unavailable, using ZXing fallback", ex);
            beginZxingScan();
        }
    }

    private void beginZxingScan() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            scanAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
            return;
        }
        try {
            IntentIntegrator integrator = new IntentIntegrator(MainActivity.this);
            integrator.setCaptureActivity(CaptureActivity.class);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
            integrator.setPrompt("وجّه الكاميرا نحو بطاقة QR الخاصة بالطالب");
            integrator.setBeepEnabled(true);
            integrator.setOrientationLocked(false);
            integrator.setBarcodeImageEnabled(false);
            integrator.initiateScan();
        } catch (Throwable ex) {
            android.util.Log.e("NaaserQR", "Unable to start QR scanner", ex);
            Toast.makeText(this, "تعذر فتح ماسح QR: " + ex, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_PHOTO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginPhotoCapture();
            else Toast.makeText(this, "يلزم السماح باستخدام الكاميرا لالتقاط صورة الطالب.", Toast.LENGTH_LONG).show();
            return;
        }
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && scanAfterPermission) {
                scanAfterPermission = false;
                beginZxingScan();
            } else {
                scanAfterPermission = false;
                Toast.makeText(this, "يلزم السماح باستخدام الكاميرا لمسح بطاقات QR.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PHOTO_REQUEST) {
            if (resultCode == RESULT_OK) processCapturedPhoto();
            else if (pendingPhotoFile != null) { pendingPhotoFile.delete(); pendingPhotoFile = null; }
            return;
        }
        if (requestCode == SCAN_ACTIVITY_REQUEST) {
            if (resultCode == RESULT_FIRST_USER) beginGmsScan();
            return;
        }
        if (requestCode == QR_SCAN_REQUEST) {
            IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if (result != null && result.getContents() != null) {
                deliverScanResult(result.getContents());
            } else if (result != null) {
                Toast.makeText(this, "تم إلغاء مسح QR", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = resultCode == RESULT_OK && data != null && data.getData() != null
                        ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        } else if (requestCode == SAVE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingFileBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) out.write(pendingFileBytes);
                    Toast.makeText(this, "تم حفظ الملف بنجاح", Toast.LENGTH_LONG).show();
                } catch (IOException ex) {
                    Toast.makeText(this, "حدث خطأ أثناء حفظ الملف", Toast.LENGTH_LONG).show();
                }
            }
            pendingFileBytes = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (instance == this) instance = null;
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }
}
