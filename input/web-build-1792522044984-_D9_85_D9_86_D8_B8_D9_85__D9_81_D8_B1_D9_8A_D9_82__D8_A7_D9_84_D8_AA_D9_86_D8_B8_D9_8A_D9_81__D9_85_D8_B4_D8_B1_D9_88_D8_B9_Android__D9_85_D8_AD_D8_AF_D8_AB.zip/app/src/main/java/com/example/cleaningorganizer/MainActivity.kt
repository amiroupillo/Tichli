package com.example.cleaningorganizer

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Person(val id: String, var name: String)
data class CleaningTurn(val date: Long, val members: MutableList<String>, val absent: MutableSet<String> = mutableSetOf(), val substitutes: MutableMap<String,String> = mutableMapOf(), val exemptNext: MutableSet<String> = mutableSetOf())

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("cleaning", MODE_PRIVATE) }
    private val people = mutableListOf<Person>()
    private val turns = mutableListOf<CleaningTurn>()
    private var startDate = todayAtNoon()
    private var interval = 8
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        if (people.isEmpty()) {
            listOf("الفرد 1", "الفرد 2", "الفرد 3", "الفرد 4", "الفرد 5").forEach { people.add(Person(java.util.UUID.randomUUID().toString(), it)) }
            save()
        }
        if (turns.isEmpty()) generateInitialTurns()
        render()
    }

    private fun todayAtNoon(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun fmt(ms: Long): String = SimpleDateFormat("EEEE، dd MMMM yyyy", Locale("ar")).format(Date(ms))
    private fun dateOnly(ms: Long): Long = Calendar.getInstance().apply { timeInMillis=ms; set(Calendar.HOUR_OF_DAY,12); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis
    private fun nextDate(ms: Long): Long = Calendar.getInstance().apply { timeInMillis=ms; add(Calendar.DAY_OF_YEAR, interval) }.timeInMillis
    private fun generateInitialTurns() {
        turns.clear()
        var date = dateOnly(startDate)
        // Each turn has three members; rotate through the active list.
        val active = people.map { it.id }
        if (active.size >= 3) {
            repeat(12) { i ->
                val members = (0..2).map { active[(i*3+it) % active.size] }.toMutableList()
                turns.add(CleaningTurn(date, members))
                date = nextDate(date)
            }
        }
        save()
    }

    private fun load() {
        interval = prefs.getInt("interval", 8)
        startDate = prefs.getLong("startDate", todayAtNoon())
        try {
            val p = JSONArray(prefs.getString("people", "[]"))
            for (i in 0 until p.length()) { val o=p.getJSONObject(i); people.add(Person(o.getString("id"),o.getString("name"))) }
            val t = JSONArray(prefs.getString("turns", "[]"))
            for (i in 0 until t.length()) {
                val o=t.getJSONObject(i); val mem=mutableListOf<String>(); val ma=o.getJSONArray("members")
                for (j in 0 until ma.length()) mem.add(ma.getString(j))
                val abs=mutableSetOf<String>(); val aa=o.optJSONArray("absent") ?: JSONArray()
                for (j in 0 until aa.length()) abs.add(aa.getString(j))
                val subs=mutableMapOf<String,String>(); val so=o.optJSONObject("substitutes") ?: JSONObject()
                so.keys().forEach { subs[it]=so.getString(it) }
                val ex=mutableSetOf<String>(); val ea=o.optJSONArray("exemptNext") ?: JSONArray()
                for (j in 0 until ea.length()) ex.add(ea.getString(j))
                turns.add(CleaningTurn(o.getLong("date"),mem,abs,subs,ex))
            }
        } catch (_: Exception) { people.clear(); turns.clear() }
    }
    private fun save() {
        val p=JSONArray(); people.forEach { p.put(JSONObject().put("id",it.id).put("name",it.name)) }
        val t=JSONArray(); turns.forEach { turn ->
            val m=JSONArray(); turn.members.forEach { m.put(it) }
            val a=JSONArray(); turn.absent.forEach { a.put(it) }
            val s=JSONObject(); turn.substitutes.forEach { (k,v)->s.put(k,v) }
            val ex=JSONArray(); turn.exemptNext.forEach { ex.put(it) }
            t.put(JSONObject().put("date",turn.date).put("members",m).put("absent",a).put("substitutes",s).put("exemptNext",ex))
        }
        prefs.edit().putString("people",p.toString()).putString("turns",t.toString()).putInt("interval",interval).putLong("startDate",startDate).apply()
    }
    private fun personName(id:String):String = people.find { it.id==id }?.name ?: "شخص محذوف"
    private fun dp(n:Int)= (n*resources.displayMetrics.density).toInt()
    private fun text(s:String, size:Float=16f):TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(0xFF17212B.toInt()); setPadding(dp(8),dp(6),dp(8),dp(6))
    }
    private fun button(s:String, action:()->Unit)=Button(this).apply { text=s; setOnClickListener { action() } }
    private fun render() {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(12),dp(16),dp(20)); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        val scroll=ScrollView(this); scroll.addView(root)
        setContentView(scroll)
        root.addView(text("منظّم فريق التنظيف",25f))
        root.addView(text("تنظيم تلقائي كل $interval أيام • ثلاثة أفراد في كل موعد",14f))
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        actions.addView(button("إدارة الأفراد") { peopleDialog() }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(button("إعداد الموعد") { settingsDialog() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(actions)
        root.addView(text("المواعيد القادمة",21f))
        if (people.size < 3) root.addView(text("أضف ثلاثة أفراد على الأقل لإنشاء جدول.",15f))
        turns.sortedBy { it.date }.take(12).forEachIndexed { index, turn ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(8)); setBackgroundColor(if(index==0) 0xFFE8F3EE.toInt() else 0xFFF2F4F6.toInt()) }
            card.addView(text("${index+1}. ${fmt(turn.date)}",17f))
            if(turn.exemptNext.isNotEmpty()) card.addView(text("إعفاء في هذا الموعد: " + turn.exemptNext.joinToString("، ") { personName(it) },14f))
            turn.members.forEach { id ->
                val absent=id in turn.absent
                val actual=turn.substitutes[id]
                card.addView(text("• ${personName(id)}" + if(absent) " — غائب" else "",14f))
                if(actual!=null) card.addView(text("   ↳ البديل: ${personName(actual)}",14f))
            }
            card.addView(button("تسجيل غياب / اختيار بديل") { substituteDialog(turn) })
            if(turn.absent.isNotEmpty()) card.addView(button("إلغاء تسجيل الغياب") { turn.absent.clear(); turn.substitutes.clear(); save(); render() })
            root.addView(card)
            val space=View(this); root.addView(space, LinearLayout.LayoutParams(1,dp(8)))
        }
        root.addView(button("إضافة موعد جديد") {
            val last=turns.maxByOrNull { it.date }?.date ?: startDate
            val ids=people.map { it.id }
            if(ids.size>=3) {
                // A substitute's completed cleaning counts as their next scheduled turn.
                // If they would otherwise be in the next team, exempt them and fill that slot fairly.
                val lastTurn=turns.maxByOrNull { it.date }
                val credited=(lastTurn?.substitutes?.values ?: emptyList()).distinct().filter { it in ids }.toMutableSet()
                val counts=ids.associateWith { id -> turns.count { turn -> id in turn.members && id !in turn.absent } }
                val ordered=ids.sortedWith(compareBy<String> { if(it in credited) 1 else 0 }.thenBy { counts[it] ?: 0 }.thenBy { personName(it) })
                val chosen=ordered.take(3).toMutableList()
                // If a credited substitute is included in the initial selection, replace with next eligible person.
                for (i in chosen.indices) {
                    if (chosen[i] in credited) {
                        val replacement=ordered.firstOrNull { it !in chosen && it !in credited }
                        if (replacement != null) chosen[i]=replacement
                    }
                }
                val exempt=credited.filter { it in ids }.toMutableSet()
                turns.add(CleaningTurn(nextDate(last),chosen,exemptNext=exempt)); save(); render()
            } else toast("يلزم وجود ثلاثة أفراد على الأقل")
        })
    }
    private fun peopleDialog() {
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),dp(8)) }
        people.forEach { p ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            row.addView(text(p.name,15f),LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("تعديل") { editPerson(p); })
            row.addView(button("حذف") {
                AlertDialog.Builder(this).setTitle("حذف ${p.name}؟").setMessage("سيبقى الاسم السابق ظاهرًا في المواعيد القديمة.").setNegativeButton("إلغاء",null).setPositiveButton("حذف") { _,_-> people.remove(p); save(); render() }.show()
            })
            layout.addView(row)
        }
        AlertDialog.Builder(this).setTitle("قائمة الأفراد").setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("إضافة فرد") { _,_-> editPerson(null) }
            .setNegativeButton("إغلاق",null).show()
    }
    private fun editPerson(person:Person?) {
        val input=EditText(this).apply { hint="اسم الفرد"; setText(person?.name ?: "") }
        AlertDialog.Builder(this).setTitle(if(person==null) "إضافة فرد" else "تعديل الاسم").setView(input)
            .setNegativeButton("إلغاء",null).setPositiveButton("حفظ") { _,_->
                val name=input.text.toString().trim()
                if(name.isNotEmpty()) {
                    if(person==null) people.add(Person(java.util.UUID.randomUUID().toString(),name)) else person.name=name
                    save()
                    if(turns.isEmpty() || turns.all { it.members.size<3 }) generateInitialTurns()
                    render()
                } else toast("أدخل اسمًا صحيحًا")
            }.show()
    }
    private fun settingsDialog() {
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),dp(8)) }
        val intervalInput=EditText(this).apply { inputType=2; setText(interval.toString()); hint="الفاصل بالأيام" }
        layout.addView(text("الفاصل بين المواعيد بالأيام"))
        layout.addView(intervalInput)
        layout.addView(button("اختيار تاريخ أول موعد") {
            val c=Calendar.getInstance().apply { timeInMillis=startDate }
            DatePickerDialog(this,{ _,y,m,d ->
                startDate=Calendar.getInstance().apply { set(y,m,d,12,0,0) }.timeInMillis
                save(); generateInitialTurns(); render()
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
        })
        AlertDialog.Builder(this).setTitle("إعداد الجدول").setView(layout).setNegativeButton("إلغاء",null)
            .setPositiveButton("حفظ") { _,_->
                val v=intervalInput.text.toString().toIntOrNull()
                if(v==null || v<1 || v>365) toast("أدخل عدد أيام بين 1 و365")
                else { interval=v; save(); generateInitialTurns(); render() }
            }.show()
    }
    private fun substituteDialog(turn:CleaningTurn) {
        val eligible=turn.members.filter { it !in turn.absent }
        val absentOptions=turn.members.map { personName(it) }.toTypedArray()
        if(turn.members.isEmpty()) return
        AlertDialog.Builder(this).setTitle("من الشخص الغائب؟").setItems(absentOptions) { _,which ->
            val absentId=turn.members[which]
            val candidates=people.filter { it.id !in turn.members && it.id !in turn.substitutes.values }
            if(candidates.isEmpty()) {
                AlertDialog.Builder(this).setMessage("لا يوجد فرد بديل خارج فريق هذا الموعد. أضف فردًا أو اختر شخصًا من القائمة.").setPositiveButton("حسنًا",null).show()
            } else {
                AlertDialog.Builder(this).setTitle("اختر البديل عن ${personName(absentId)}")
                    .setItems(candidates.map { it.name }.toTypedArray()) { _,pick ->
                        turn.absent.add(absentId)
                        turn.substitutes[absentId]=candidates[pick].id
                        save(); render()
                        toast("سُجّل البديل. تُحتسب هذه المشاركة بدلًا من دوره القادم، ويُعفى من الموعد التالي إذا كان ضمن الفريق.")
                    }.setNegativeButton("إلغاء",null).show()
            }
        }.setNegativeButton("إلغاء",null).show()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
