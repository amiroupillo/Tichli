@echo off
echo Gradle Wrapper JAR is not bundled in this environment. Open in Android Studio or generate wrapper files with Gradle 8.11.1.
exit /b 1
