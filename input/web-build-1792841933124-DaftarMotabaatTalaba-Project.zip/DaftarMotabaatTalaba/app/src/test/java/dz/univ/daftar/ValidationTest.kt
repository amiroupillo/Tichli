package dz.univ.daftar

import dz.univ.daftar.data.Evaluation
import dz.univ.daftar.data.Student
import dz.univ.daftar.domain.Validation
import org.junit.Assert.*
import org.junit.Test

class ValidationTest {
    @Test fun studentRequiresNameAndNumber() {
        assertNotNull(Validation.studentError(Student(fullName="", studentNumber="123")))
        assertNotNull(Validation.studentError(Student(fullName="اسم", studentNumber="")))
        assertNull(Validation.studentError(Student(fullName="اسم", studentNumber="123")))
    }
    @Test fun scoreBoundsAreChecked() {
        assertNotNull(Validation.scoreError(-0.1, 6.0))
        assertNotNull(Validation.scoreError(6.1, 6.0))
        assertNull(Validation.scoreError(6.0, 6.0))
    }
    @Test fun incompleteEvaluationIsNotZero() {
        val e=Evaluation(studentId=1, explanation=0.0)
        assertFalse(e.isComplete())
        assertNull(e.total())
    }
    @Test fun completeEvaluationTotalsTwenty() {
        val e=Evaluation(studentId=1, explanation=6.0, coverage=3.0, methodology=3.0, attendance=2.0, writtenTest=6.0)
        assertTrue(e.isComplete())
        assertEquals(20.0, e.total()!!, 0.001)
    }
}
