package dz.univ.daftar.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dz.univ.daftar.data.*
import dz.univ.daftar.domain.Validation
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class DaftarViewModel(app: Application) : AndroidViewModel(app) {
    private val db = DaftarDatabase.get(app)
    private val query = MutableStateFlow("")
    private val year = MutableStateFlow("")
    private val level = MutableStateFlow("")
    private val module = MutableStateFlow("")
    private val groupName = MutableStateFlow("")
    val search = query.asStateFlow()
    val students = combine(query, year, level, module, groupName) { q, y, l, m, g -> arrayOf(q,y,l,m,g) }
        .flatMapLatest { db.students().observeStudents(it[0],it[1],it[2],it[3],it[4]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val studentCount = db.students().count().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val sessions = db.sessions().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val presentCount = db.attendance().presentCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val absentCount = db.attendance().absentCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val lateCount = db.attendance().lateCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    fun setSearch(v: String) { query.value = v }
    fun saveStudent(student: Student, done: (String?) -> Unit) = viewModelScope.launch {
        Validation.studentError(student)?.let { done(it); return@launch }
        try {
            if (student.id == 0L) db.students().insert(student) else db.students().update(student)
            done(null)
        } catch (_: android.database.sqlite.SQLiteConstraintException) {
            done("الرقم الجامعي مستخدم من قبل")
        } catch (_: Exception) { done("تعذر حفظ بيانات الطالب") }
    }
    fun deleteStudent(student: Student, done: (Boolean) -> Unit) = viewModelScope.launch {
        try { db.students().delete(student); done(true) } catch (_: Exception) { done(false) }
    }
    fun student(id: Long) = db.students().observeStudent(id)
    fun saveSession(session: ClassSession, done: (String?) -> Unit) = viewModelScope.launch {
        try { if (session.id == 0L) db.sessions().insert(session) else db.sessions().update(session); done(null) }
        catch (_: Exception) { done("تعذر حفظ الحصة") }
    }
    fun recordAttendance(studentId: Long, sessionId: Long, status: String, done: (String?) -> Unit) = viewModelScope.launch {
        if (status !in listOf("حاضر", "غائب", "متأخر")) { done("حالة حضور غير صالحة"); return@launch }
        try { db.attendance().insert(AttendanceRecord(studentId=studentId, sessionId=sessionId, status=status)); done(null) }
        catch (_: Exception) { done("يوجد سجل لهذا الطالب في الحصة أو تعذر الحفظ") }
    }
    fun updateAttendance(record: AttendanceRecord, status: String, done: (String?) -> Unit) = viewModelScope.launch {
        if (status !in listOf("حاضر", "غائب", "متأخر")) { done("حالة حضور غير صالحة"); return@launch }
        try { db.attendance().update(record.copy(status=status)); done(null) } catch (_: Exception) { done("تعذر تعديل الحضور") }
    }
    fun attendanceFor(id: Long) = db.attendance().forStudent(id)
    fun absenceDates(id: Long) = db.attendance().absenceDates(id)
    fun evaluation(id: Long) = db.evaluations().observe(id)
    fun saveEvaluation(e: Evaluation, done: (String?) -> Unit) = viewModelScope.launch {
        Validation.evaluationError(e)?.let { done(it); return@launch }
        try { db.evaluations().save(e); done(null) } catch (_: Exception) { done("تعذر حفظ التقييم") }
    }
}
