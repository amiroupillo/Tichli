package dz.univ.daftar.data

import androidx.room.*

@Entity(
    tableName = "students",
    indices = [Index(value = ["studentNumber"], unique = true), Index("fullName"), Index("researchTopic")]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val studentNumber: String,
    val phone: String = "",
    val academicYear: String = "",
    val level: String = "",
    val module: String = "",
    val groupName: String = "",
    val researchTopic: String = "",
    val professorNotes: String = ""
)

@Entity(tableName = "sessions", indices = [Index("module"), Index("groupName")])
data class ClassSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateIso: String,
    val module: String,
    val groupName: String,
    val label: String = ""
)

@Entity(
    tableName = "attendance_records",
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = ClassSession::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["studentId", "sessionId"], unique = true), Index("sessionId"), Index("studentId")]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val sessionId: Long,
    val status: String
)

@Entity(
    tableName = "evaluations",
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["studentId"], unique = true)]
)
data class Evaluation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val explanation: Double? = null,
    val coverage: Double? = null,
    val methodology: Double? = null,
    val attendance: Double? = null,
    val writtenTest: Double? = null
) {
    fun isComplete() = explanation != null && coverage != null && methodology != null && attendance != null && writtenTest != null
    fun total(): Double? = if (isComplete()) explanation!! + coverage!! + methodology!! + attendance!! + writtenTest!! else null
}

data class AttendanceSummary(val total: Int, val present: Int, val absent: Int, val late: Int) {
    fun percentage(): Double = if (total == 0) 0.0 else present.toDouble() * 100.0 / total
}
