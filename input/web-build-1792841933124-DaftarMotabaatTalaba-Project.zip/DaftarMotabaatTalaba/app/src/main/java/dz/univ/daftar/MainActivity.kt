package dz.univ.daftar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import dz.univ.daftar.data.*
import dz.univ.daftar.ui.DaftarViewModel

class MainActivity : ComponentActivity() {
    private val vm: DaftarViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setContent { DaftarTheme { DaftarApp(vm) } }
    }
}
@Composable private fun DaftarTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF164A63), secondary = androidx.compose.ui.graphics.Color(0xFFB38A45)), content = content)
}
@Composable private fun DaftarApp(vm: DaftarViewModel) {
    val nav = rememberNavController()
    Scaffold(topBar = { TopAppBar(title = { Text("دفتر متابعة الطلبة") }, navigationIcon = { Icon(Icons.Default.School, null, Modifier.padding(start=12.dp)) }) }) { padding ->
        NavHost(navController=nav, startDestination="home", modifier=Modifier.padding(padding)) {
            composable("home") {
                val count by vm.studentCount.collectAsStateWithLifecycle()
                val present by vm.presentCount.collectAsStateWithLifecycle()
                val absent by vm.absentCount.collectAsStateWithLifecycle()
                val late by vm.lateCount.collectAsStateWithLifecycle()
                HomeScreen(count,present,absent,late, onStudents={nav.navigate("students")}, onSessions={nav.navigate("sessions")}, onReports={nav.navigate("reports")})
            }
            composable("students") { StudentList(vm, onBack={nav.popBackStack()}, onAdd={nav.navigate("edit/0")}, onOpen={nav.navigate("detail/$it")}) }
            composable("edit/{id}", arguments=listOf(navArgument("id"){type=NavType.LongType})) { entry ->
                StudentEditor(vm, entry.arguments?.getLong("id") ?: 0L, onDone={nav.popBackStack()})
            }
            composable("detail/{id}", arguments=listOf(navArgument("id"){type=NavType.LongType})) { entry ->
                StudentDetail(vm, entry.arguments?.getLong("id") ?: 0L, onEdit={nav.navigate("edit/$it")}, onBack={nav.popBackStack()})
            }
            composable("sessions") { SessionScreen(vm, onBack={nav.popBackStack()}) }
            composable("reports") { ReportsScreen(vm, onBack={nav.popBackStack()}) }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun HomeScreen(count:Int,present:Int,absent:Int,late:Int,onStudents:()->Unit,onSessions:()->Unit,onReports:()->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("الأستاذ الدكتور ناصر يوسف", style=MaterialTheme.typography.titleLarge)
        Text("لوحة المتابعة الجامعية", style=MaterialTheme.typography.bodyLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StatCard("الطلبة",count.toString(),Modifier.weight(1f))
            StatCard("حاضر",present.toString(),Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StatCard("غائب",absent.toString(),Modifier.weight(1f))
            StatCard("متأخر",late.toString(),Modifier.weight(1f))
        }
        Button(onClick=onStudents, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Groups,null); Spacer(Modifier.width(8.dp)); Text("إدارة الطلبة") }
        OutlinedButton(onClick=onSessions, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.EventAvailable,null); Spacer(Modifier.width(8.dp)); Text("الحصص والحضور") }
        OutlinedButton(onClick=onReports, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Assessment,null); Spacer(Modifier.width(8.dp)); Text("التقارير والتصدير") }
        Spacer(Modifier.weight(1f))
        Text("تُحفظ البيانات محليًا على هذا الجهاز.", style=MaterialTheme.typography.bodySmall)
    }
}
@Composable private fun StatCard(label:String,value:String,modifier:Modifier=Modifier) {
    Card(modifier) { Column(Modifier.padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) { Text(value, style=MaterialTheme.typography.headlineMedium); Text(label) } }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun StudentList(vm:DaftarViewModel,onBack:()->Unit,onAdd:()->Unit,onOpen:(Long)->Unit) {
    val students by vm.students.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    var deleteTarget by remember { mutableStateOf<Student?>(null) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowForward,null)}
            OutlinedTextField(search,vm::setSearch,Modifier.weight(1f),label={Text("بحث بالاسم أو الرقم أو موضوع البحث")},singleLine=true)
            IconButton(onClick=onAdd){Icon(Icons.Default.PersonAdd,null)}
        }
        Text("عدد النتائج: ${students.size}", Modifier.padding(vertical=8.dp))
        if(students.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(if(search.isBlank()) "لا توجد بيانات بعد. أضف أول طالب." else "لا توجد نتائج مطابقة.")}
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(students,key={it.id}) { s ->
                Card(onClick={onOpen(s.id)},modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(s.fullName,style=MaterialTheme.typography.titleMedium); Text("الرقم الجامعي: ${s.studentNumber}"); if(s.researchTopic.isNotBlank()) Text("موضوع البحث: ${s.researchTopic}") }
                        IconButton(onClick={deleteTarget=s}){Icon(Icons.Default.Delete,null)}
                    }
                }
            }
        }
    }
    deleteTarget?.let { s -> AlertDialog(onDismissRequest={deleteTarget=null},title={Text("تأكيد الحذف")},text={Text("هل تريد حذف الطالب ${s.fullName}؟ ستُحذف سجلاته المرتبطة بالحضور والتقييم.")},confirmButton={TextButton(onClick={vm.deleteStudent(s){ok->message=if(ok)"تم حذف الطالب" else "تعذر الحذف"};deleteTarget=null}){Text("حذف")}},dismissButton={TextButton(onClick={deleteTarget=null}){Text("إلغاء")}}) }
    if(message.isNotBlank()) LaunchedEffect(message) { kotlinx.coroutines.delay(2200); message="" }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun StudentEditor(vm:DaftarViewModel,id:Long,onDone:()->Unit) {
    var fullName by remember { mutableStateOf("") }; var number by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }; var level by remember { mutableStateOf("") }; var module by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("") }; var topic by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(id==0L) }; var error by remember { mutableStateOf("") }
    LaunchedEffect(id) { if(id!=0L) vm.student(id).collect { s -> if(s!=null){fullName=s.fullName;number=s.studentNumber;phone=s.phone;year=s.academicYear;level=s.level;module=s.module;group=s.groupName;topic=s.researchTopic;notes=s.professorNotes;loaded=true} } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if(id==0L)"إضافة طالب" else "تعديل بيانات الطالب",style=MaterialTheme.typography.headlineSmall)
        if(!loaded) CircularProgressIndicator() else {
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.weight(1f)) {
                item { Field("الاسم الكامل",fullName,{fullName=it},true) }
                item { Field("الرقم الجامعي",number,{number=it},true) }
                item { Field("رقم الهاتف",phone,{phone=it}) }
                item { Field("السنة الجامعية",year,{year=it}) }
                item { Field("المستوى الدراسي",level,{level=it}) }
                item { Field("المقياس",module,{module=it}) }
                item { Field("الفوج",group,{group=it}) }
                item { Field("موضوع البحث",topic,{topic=it}) }
                item { OutlinedTextField(notes,{notes=it},Modifier.fillMaxWidth(),label={Text("ملاحظات الأستاذ")},minLines=3) }
            }
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
            Button(onClick={vm.saveStudent(Student(id=id,fullName=fullName.trim(),studentNumber=number.trim(),phone=phone,academicYear=year,level=level,module=module,groupName=group,researchTopic=topic,professorNotes=notes)){err->if(err==null)onDone() else error=err}},modifier=Modifier.fillMaxWidth()){Text("حفظ البيانات")}
            OutlinedButton(onClick=onDone,modifier=Modifier.fillMaxWidth()){Text("إلغاء")}
        }
    }
}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit,required:Boolean=false) {
    OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(if(required)"$label *" else label)},singleLine=true)
}
@Composable private fun StudentDetail(vm:DaftarViewModel,id:Long,onEdit:(Long)->Unit,onBack:()->Unit) {
    val flow= remember(id) { vm.student(id) }
    val student by flow.collectAsStateWithLifecycle(initialValue=null)
    val attendance by vm.attendanceFor(id).collectAsStateWithLifecycle(initialValue=emptyList())
    val dates by vm.absenceDates(id).collectAsStateWithLifecycle(initialValue=emptyList())
    val evaluation by vm.evaluation(id).collectAsStateWithLifecycle(initialValue=null)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowForward,null)};Text("الملف الفردي",style=MaterialTheme.typography.headlineSmall)}
        if(student==null) Text("تعذر العثور على الطالب") else {
            val s=student!!
            Text(s.fullName,style=MaterialTheme.typography.titleLarge)
            listOf("الرقم الجامعي" to s.studentNumber,"الهاتف" to s.phone,"السنة الجامعية" to s.academicYear,"المستوى" to s.level,"المقياس" to s.module,"الفوج" to s.groupName,"موضوع البحث" to s.researchTopic,"ملاحظات الأستاذ" to s.professorNotes).forEach { (k,v)-> if(v.isNotBlank()) Text("$k: $v",Modifier.padding(vertical=3.dp)) }
            Divider(Modifier.padding(vertical=8.dp))
            Text("سجلات الحضور: ${attendance.size}")
            Text("تواريخ الغياب: ${if(dates.isEmpty())"لا يوجد غياب مسجل" else dates.joinToString("، ")}")
            Text("التقييم: ${evaluation?.total()?.let{"%.2f / 20".format(it)} ?: "غير مكتمل"}")
            Button(onClick={onEdit(s.id),modifier=Modifier.fillMaxWidth()){Text("تعديل البيانات")}
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun SessionScreen(vm:DaftarViewModel,onBack:()->Unit) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    var date by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var module by remember { mutableStateOf("") }; var group by remember { mutableStateOf("") }; var label by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowForward,null)};Text("الحصص والحضور",style=MaterialTheme.typography.headlineSmall)}
        OutlinedTextField(date,{date=it},Modifier.fillMaxWidth(),label={Text("تاريخ الحصة (YYYY-MM-DD)")},singleLine=true)
        OutlinedTextField(module,{module=it},Modifier.fillMaxWidth(),label={Text("المقياس")},singleLine=true)
        OutlinedTextField(group,{group=it},Modifier.fillMaxWidth(),label={Text("الفوج")},singleLine=true)
        OutlinedTextField(label,{label=it},Modifier.fillMaxWidth(),label={Text("وصف الحصة (اختياري)")},singleLine=true)
        Button(onClick={ if(runCatching{java.time.LocalDate.parse(date)}.isFailure || module.isBlank() || group.isBlank()) msg="أدخل تاريخًا صحيحًا والمقياس والفوج" else vm.saveSession(ClassSession(dateIso=date,module=module,groupName=group,label=label)){e->msg=e?: "تم إنشاء الحصة"} },modifier=Modifier.fillMaxWidth()){Text("إنشاء حصة")}
        if(msg.isNotBlank()) Text(msg)
        Text("الحصص المسجلة",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=12.dp))
        LazyColumn { items(sessions,key={it.id}) { s -> ListItem(headlineContent={Text("${s.dateIso} — ${s.module}")}, supportingContent={Text("الفوج: ${s.groupName}${if(s.label.isBlank())"" else " · ${s.label}"}")}) } }
    }
}
@Composable private fun ReportsScreen(vm:DaftarViewModel,onBack:()->Unit) {
    val students by vm.students.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowForward,null)};Text("التقارير والتصدير",style=MaterialTheme.typography.headlineSmall)}
        Text("ملخص محلي",style=MaterialTheme.typography.titleMedium)
        Text("عدد الطلبة: ${students.size}")
        Text("عدد الحصص: ${sessions.size}")
        Text("التصدير CSV والنسخ الاحتياطي JSON لم تُفعّل بعد في هذه النسخة.")
    }
}
