package dz.univ.daftar.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("""SELECT * FROM students WHERE
        (:query = '' OR fullName LIKE '%' || :query || '%' OR studentNumber LIKE '%' || :query || '%' OR researchTopic LIKE '%' || :query || '%')
        AND (:year = '' OR academicYear = :year)
        AND (:level = '' OR level = :level)
        AND (:module = '' OR module = :module)
        AND (:groupName = '' OR groupName = :groupName)
        ORDER BY fullName COLLATE NOCASE ASC""")
    fun observeStudents(query: String, year: String, level: String, module: String, groupName: String): Flow<List<Student>>
    @Query("SELECT * FROM students WHERE id = :id") fun observeStudent(id: Long): Flow<Student?>
    @Query("SELECT * FROM students ORDER BY fullName COLLATE NOCASE") suspend fun all(): List<Student>
    @Query("SELECT * FROM students WHERE id = :id") suspend fun get(id: Long): Student?
    @Insert suspend fun insert(student: Student): Long
    @Update suspend fun update(student: Student)
    @Delete suspend fun delete(student: Student)
    @Query("SELECT COUNT(*) FROM students") fun count(): Flow<Int>
    @Query("SELECT DISTINCT academicYear FROM students WHERE academicYear != '' ORDER BY academicYear") fun years(): Flow<List<String>>
}
@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY dateIso DESC, id DESC") fun observeAll(): Flow<List<ClassSession>>
    @Query("SELECT * FROM sessions WHERE id = :id") suspend fun get(id: Long): ClassSession?
    @Insert suspend fun insert(session: ClassSession): Long
    @Update suspend fun update(session: ClassSession)
    @Delete suspend fun delete(session: ClassSession)
    @Query("SELECT * FROM sessions") suspend fun all(): List<ClassSession>
}
@Dao
interface AttendanceDao {
    @Insert suspend fun insert(record: AttendanceRecord): Long
    @Update suspend fun update(record: AttendanceRecord)
    @Query("SELECT * FROM attendance_records WHERE studentId = :studentId ORDER BY sessionId DESC") fun forStudent(studentId: Long): Flow<List<AttendanceRecord>>
    @Query("SELECT * FROM attendance_records") suspend fun all(): List<AttendanceRecord>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE status = 'حاضر'") fun presentCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE status = 'غائب'") fun absentCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE status = 'متأخر'") fun lateCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE studentId = :studentId") fun countForStudent(studentId: Long): Flow<Int>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE studentId = :studentId AND status = 'حاضر'") fun presentForStudent(studentId: Long): Flow<Int>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE studentId = :studentId AND status = 'غائب'") fun absentForStudent(studentId: Long): Flow<Int>
    @Query("SELECT COUNT(*) FROM attendance_records WHERE studentId = :studentId AND status = 'متأخر'") fun lateForStudent(studentId: Long): Flow<Int>
    @Query("SELECT DISTINCT s.dateIso FROM attendance_records a JOIN sessions s ON a.sessionId=s.id WHERE a.studentId=:studentId AND a.status='غائب' ORDER BY s.dateIso DESC") fun absenceDates(studentId: Long): Flow<List<String>>
}
@Dao
interface EvaluationDao {
    @Query("SELECT * FROM evaluations WHERE studentId = :studentId") fun observe(studentId: Long): Flow<Evaluation?>
    @Query("SELECT * FROM evaluations") suspend fun all(): List<Evaluation>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(evaluation: Evaluation)
    @Query("DELETE FROM evaluations") suspend fun clear()
}
@Database(entities = [Student::class, ClassSession::class, AttendanceRecord::class, Evaluation::class], version = 1, exportSchema = true)
abstract class DaftarDatabase : RoomDatabase() {
    abstract fun students(): StudentDao
    abstract fun sessions(): SessionDao
    abstract fun attendance(): AttendanceDao
    abstract fun evaluations(): EvaluationDao
    companion object {
        @Volatile private var INSTANCE: DaftarDatabase? = null
        fun get(context: Context): DaftarDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, DaftarDatabase::class.java, "daftar_students.db").build().also { INSTANCE = it }
        }
    }
}
