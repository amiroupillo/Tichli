package dz.univ.daftar.domain

import dz.univ.daftar.data.Evaluation
import dz.univ.daftar.data.Student

object Validation {
    fun studentError(s: Student): String? = when {
        s.fullName.isBlank() -> "يرجى إدخال الاسم الكامل"
        s.studentNumber.isBlank() -> "يرجى إدخال الرقم الجامعي"
        else -> null
    }
    fun scoreError(value: Double?, max: Double): String? =
        if (value != null && (value < 0.0 || value > max)) "العلامة يجب أن تكون بين 0 و $max" else null

    fun evaluationError(e: Evaluation): String? =
        scoreError(e.explanation, 6.0) ?: scoreError(e.coverage, 3.0) ?:
        scoreError(e.methodology, 3.0) ?: scoreError(e.attendance, 2.0) ?:
        scoreError(e.writtenTest, 6.0)
}
