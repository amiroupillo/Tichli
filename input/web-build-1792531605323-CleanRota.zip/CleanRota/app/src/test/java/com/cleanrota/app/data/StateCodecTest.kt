package com.cleanrota.app.data

import com.cleanrota.app.domain.RotaState
import com.cleanrota.app.domain.Scheduler
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class StateCodecTest {

    @Test
    fun `round trip keeps everything`() {
        var s = listOf("أحمد", "بسمة", "جمال", "دعاء", "ريم", "سعد", "ياسر").fold(RotaState(startDate = LocalDate.of(2026, 10, 20))) { st, n ->
            Scheduler.addMember(st, n, id = n)
        }
        s = Scheduler.setSubstitution(s, "بسمة", "سعد")
        s = Scheduler.completeSession(s)
        s = Scheduler.setSubstitution(s, "دعاء", "ياسر")
        s = Scheduler.setActive(s, "ريم", false)

        assertEquals(s, StateCodec.decode(StateCodec.encode(s)))
    }
}
