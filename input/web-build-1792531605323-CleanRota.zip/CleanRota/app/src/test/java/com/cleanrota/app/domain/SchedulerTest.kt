package com.cleanrota.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SchedulerTest {

    private val start = LocalDate.of(2026, 10, 20) // ثلاثاء

    private fun rota(vararg names: String, startDate: LocalDate = start): RotaState =
        names.fold(RotaState(startDate = startDate)) { s, n -> Scheduler.addMember(s, n, id = n) }

    private fun teams(state: RotaState, n: Int) = Scheduler.project(state, n).map { it.team }

    // ───────────── التواريخ ─────────────

    @Test
    fun `every session is a Tuesday inside its 8-day cycle`() {
        for (s in listOf(start, start.plusDays(1), start.plusDays(3), start.plusDays(6))) {
            for (k in 0..200) {
                val d = Scheduler.sessionDate(s, k)
                val anchor = s.plusDays(8L * k)
                assertEquals(DayOfWeek.TUESDAY, d.dayOfWeek)
                assertTrue(d >= anchor && d <= anchor.plusDays(7))
            }
        }
    }

    @Test
    fun `average cadence is exactly 8 days and gaps are 7 or 14`() {
        val dates = (0..7).map { Scheduler.sessionDate(start, it) }
        val firstGaps: List<Long> = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b) }
        assertEquals(listOf(14L, 7L, 7L, 7L, 7L, 7L, 7L), firstGaps)
        assertEquals(56L, ChronoUnit.DAYS.between(dates[0], dates[7]))
        val gaps = (0..300).map { Scheduler.sessionDate(start, it) }.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b) }
        assertTrue(gaps.all { it == 7L || it == 14L })
    }

    @Test
    fun `first date examples`() {
        assertEquals(LocalDate.of(2026, 10, 20), Scheduler.sessionDate(start, 0))
        assertEquals(LocalDate.of(2026, 11, 3), Scheduler.sessionDate(start, 1))
        assertEquals(LocalDate.of(2026, 11, 10), Scheduler.sessionDate(start, 2))
        assertEquals(LocalDate.of(2026, 10, 27), Scheduler.sessionDate(LocalDate.of(2026, 10, 23), 0)) // جمعة → ثلاثاء
    }

    // ───────────── الدور ─────────────

    @Test
    fun `plain rotation with 6 members`() {
        val t = teams(rota("A", "B", "C", "D", "E", "F"), 3)
        assertEquals(listOf(listOf("A", "B", "C"), listOf("D", "E", "F"), listOf("A", "B", "C")), t)
    }

    @Test
    fun `plain rotation with 7 members wraps around`() {
        val t = teams(rota("A", "B", "C", "D", "E", "F", "G"), 3)
        assertEquals(listOf(listOf("A", "B", "C"), listOf("D", "E", "F"), listOf("G", "A", "B")), t)
    }

    @Test
    fun `equal participation over a long run without absences`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        val count = mutableMapOf<String, Int>()
        repeat(70) {
            Scheduler.finalTeam(s).forEach { count[it] = (count[it] ?: 0) + 1 }
            s = Scheduler.completeSession(s)
        }
        assertTrue(count.values.all { it == 30 })
    }

    @Test
    fun `fewer than three members gives a smaller team`() {
        val s = rota("A", "B")
        assertEquals(listOf("A", "B"), Scheduler.currentTeam(s))
        assertEquals(2, Scheduler.project(s, 3).first().team.size)
    }

    // ───────────── قاعدة البديل ─────────────

    @Test
    fun `absent person returns next time and substitute counts instead of his turn`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, absentId = "B", substituteId = "F")
        assertEquals(listOf("A", "F", "C"), Scheduler.finalTeam(s))

        s = Scheduler.completeSession(s)
        assertEquals(listOf("B", "D", "E", "G", "A", "C", "F"), s.queue)
        assertEquals(listOf("F"), s.exemptNext)
        // الغائب B في الموعد التالي مباشرة، و F لا يظهر (مشاركته احتُسبت بدل دوره)
        assertEquals(listOf("B", "D", "E"), Scheduler.finalTeam(s))
        assertEquals(listOf("G", "A", "C"), teams(s, 2)[1])
        assertEquals(listOf("F", "B", "D"), teams(s, 3)[2])
    }

    @Test
    fun `substitute who was next in line is exempt from the next appointment`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, "B", "D") // D كان أول الدور القادم
        s = Scheduler.completeSession(s)
        val next = teams(s, 2)
        assertEquals(listOf("B", "E", "F"), next[0])
        assertFalse("D" in next[0])
        assertFalse("D" in next[1])
    }

    @Test
    fun `exempt members are skipped only when enough others exist`() {
        assertEquals(listOf("A", "B", "C"), Scheduler.pickTeam(listOf("D", "A", "B", "C"), listOf("D")))
        assertEquals(listOf("A", "B", "C"), Scheduler.pickTeam(listOf("A", "B", "C"), listOf("C")))
    }

    @Test
    fun `exemption is reported for the next session`() {
        val s = RotaState(
            startDate = start,
            members = listOf("D", "A", "B", "C").map { Member(it, it) },
            queue = listOf("D", "A", "B", "C"),
            exemptNext = listOf("D")
        )
        assertEquals(listOf("D"), Scheduler.exemptApplied(s))
        assertEquals(listOf("A", "B", "C"), Scheduler.finalTeam(s))
    }

    @Test
    fun `two substitutions in the same session`() {
        var s = rota("A", "B", "C", "D", "E", "F", "G")
        s = Scheduler.setSubstitution(s, "A", "E")
        s = Scheduler.setSubstitution(s, "B", "F")
        assertEquals(listOf("E", "F", "C"), Scheduler.finalTeam(s))
        s = Scheduler.completeSession(s)
        assertEquals(listOf("A", "B", "D", "G", "C", "E", "F"), s.queue)
    }

    @Test
    fun `invalid substitutions are rejected`() {
        val s = rota("A", "B", "C", "D", "E", "F", "G")
        assertEquals(s, Scheduler.setSubstitution(s, "A", "B"))   // البديل أصلًا في الفريق
        assertEquals(s, Scheduler.setSubstitution(s, "D", "E"))   // الغائب ليس في الفريق
        val withInactive = Scheduler.setActive(s, "F", false)
        assertEquals(withInactive, Scheduler.setSubstitution(withInactive, "A", "F")) // بديل غير نشط
        val one = Scheduler.setSubstitution(s, "A", "D")
        assertEquals(one, Scheduler.setSubstitution(one, "B", "D")) // نفس البديل مرتين
    }

    @Test
    fun `clearing a substitution restores the original team`() {
        var s = Scheduler.setSubstitution(rota("A", "B", "C", "D"), "A", "D")
        s = Scheduler.clearSubstitution(s, "A")
        assertEquals(listOf("A", "B", "C"), Scheduler.finalTeam(s))
    }

    @Test
    fun `with four members the exempt substitute is not in the next team`() {
        var s = Scheduler.setSubstitution(rota("A", "B", "C", "D"), "A", "D")
        s = Scheduler.completeSession(s)
        assertEquals(listOf("A", "B", "C"), Scheduler.finalTeam(s))
    }

    // ───────────── إدارة الأفراد ─────────────

    @Test
    fun `add edit and delete members`() {
        var s = rota("A", "B", "C")
        s = Scheduler.addMember(s, "  D ", id = "D")
        assertEquals(listOf("A", "B", "C", "D"), s.queue)
        assertEquals(s, Scheduler.addMember(s, "d"))              // اسم مكرر
        s = Scheduler.renameMember(s, "D", "Dina")
        assertEquals("Dina", s.members.first { it.id == "D" }.name)
        s = Scheduler.deleteMember(s, "B")
        assertEquals(listOf("A", "C", "D"), s.queue)
        assertEquals(3, s.members.size)
    }

    @Test
    fun `deactivating removes from queue and reactivating appends`() {
        var s = rota("A", "B", "C", "D")
        s = Scheduler.setActive(s, "B", false)
        assertEquals(listOf("A", "C", "D"), s.queue)
        s = Scheduler.setActive(s, "B", true)
        assertEquals(listOf("A", "C", "D", "B"), s.queue)
    }

    @Test
    fun `member edits drop invalid pending substitutions`() {
        val base = Scheduler.setSubstitution(rota("A", "B", "C", "D", "E", "F", "G"), "B", "F")
        assertTrue(Scheduler.deleteMember(base, "F").pending.isEmpty())
        assertTrue(Scheduler.setActive(base, "B", false).pending.isEmpty())
        assertTrue(Scheduler.deleteMember(base, "B").pending.isEmpty())
    }

    @Test
    fun `history keeps names after a member is deleted`() {
        var s = Scheduler.completeSession(rota("A", "B", "C", "D"))
        s = Scheduler.deleteMember(s, "A")
        assertEquals(listOf("A", "B", "C"), s.history.single().team)
    }

    @Test
    fun `start date only changeable before first session`() {
        val s = rota("A", "B", "C")
        val moved = Scheduler.setStartDate(s, LocalDate.of(2026, 11, 1))
        assertEquals(LocalDate.of(2026, 11, 3), Scheduler.sessionDate(moved.startDate, moved.cycleIndex))
        val after = Scheduler.completeSession(s)
        assertEquals(after, Scheduler.setStartDate(after, LocalDate.of(2027, 1, 1)))
    }

    // ───────────── خصائص عامة (عشوائية بذرة ثابتة) ─────────────

    @Test
    fun `random absences never break invariants`() {
        val rnd = Random(42)
        var s = rota("A", "B", "C", "D", "E", "F", "G", "H")
        val ids = s.members.map { it.id }.toSet()
        repeat(400) {
            val base = Scheduler.currentTeam(s)
            if (rnd.nextInt(3) == 0) {
                val absent = base.random(rnd)
                val cands = Scheduler.eligibleSubstitutes(s, absent)
                if (cands.isNotEmpty()) s = Scheduler.setSubstitution(s, absent, cands.random(rnd))
            }
            val team = Scheduler.finalTeam(s)
            assertEquals(3, team.size)
            assertEquals(3, team.toSet().size)
            assertEquals(ids, s.queue.toSet())
            assertEquals(s.queue.size, s.queue.toSet().size)
            assertEquals(DayOfWeek.TUESDAY, Scheduler.sessionDate(s.startDate, s.cycleIndex).dayOfWeek)
            s = Scheduler.completeSession(s)
            // الغائب يُبرمج في الموعد التالي مباشرة
            val absentees = s.queue.take(s.history.last().substitutions.size)
            assertEquals(absentees.toSet(), Scheduler.currentTeam(s).take(absentees.size).toSet())
        }
    }

    @Test
    fun `project first entry reflects pending substitutions`() {
        val s = Scheduler.setSubstitution(rota("A", "B", "C", "D", "E"), "A", "E")
        val p = Scheduler.project(s, 4)
        assertEquals(4, p.size)
        assertEquals(listOf("E", "B", "C"), p[0].team)
        assertEquals(listOf("A", "D", "B").toSet(), p[1].team.toSet())
        assertTrue(p.all { it.date.dayOfWeek == DayOfWeek.TUESDAY })
    }
}
