package com.cleanrota.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.cleanrota.app.data.RotaStore
import com.cleanrota.app.domain.RotaState
import com.cleanrota.app.domain.Scheduler
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RotaViewModel(app: Application) : AndroidViewModel(app) {

    private val store = RotaStore(app)
    private val _state = MutableStateFlow(store.load(LocalDate.now()))
    val state: StateFlow<RotaState> = _state.asStateFlow()

    private fun mutate(block: (RotaState) -> RotaState) {
        val next = block(_state.value)
        _state.value = next
        store.save(next)
    }

    fun addMember(name: String) = mutate { Scheduler.addMember(it, name) }
    fun renameMember(id: String, name: String) = mutate { Scheduler.renameMember(it, id, name) }
    fun setActive(id: String, active: Boolean) = mutate { Scheduler.setActive(it, id, active) }
    fun deleteMember(id: String) = mutate { Scheduler.deleteMember(it, id) }

    fun setSubstitute(absentId: String, substituteId: String) =
        mutate { Scheduler.setSubstitution(it, absentId, substituteId) }

    fun clearSubstitute(absentId: String) = mutate { Scheduler.clearSubstitution(it, absentId) }
    fun completeSession() = mutate { Scheduler.completeSession(it) }
    fun setStartDate(date: LocalDate) = mutate { Scheduler.setStartDate(it, date) }
}
