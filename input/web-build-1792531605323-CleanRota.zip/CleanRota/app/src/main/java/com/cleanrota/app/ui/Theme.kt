package com.cleanrota.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val LightColors = lightColorScheme(
    primary = Color(0xFF00796B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB2DFDB),
    onPrimaryContainer = Color(0xFF00201C),
    secondaryContainer = Color(0xFFE0F2F1),
    onSecondaryContainer = Color(0xFF0B2B27),
    tertiary = Color(0xFFB26A00),
    background = Color(0xFFF7FBFA),
    surface = Color(0xFFF7FBFA)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DB6AC),
    onPrimary = Color(0xFF003732),
    primaryContainer = Color(0xFF00504A),
    onPrimaryContainer = Color(0xFFB2DFDB),
    secondaryContainer = Color(0xFF1F3835),
    onSecondaryContainer = Color(0xFFD7EFEB),
    tertiary = Color(0xFFFFB74D)
)

@Composable
fun CleanRotaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}

private val arabic: Locale = Locale.forLanguageTag("ar")
private val fullFmt = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", arabic)
private val shortFmt = DateTimeFormatter.ofPattern("EEE d MMM yyyy", arabic)

fun LocalDate.arFull(): String = format(fullFmt)
fun LocalDate.arShort(): String = format(shortFmt)
