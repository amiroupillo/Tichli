package com.cleanrota.app.data

import android.content.Context
import com.cleanrota.app.domain.HistoryEntry
import com.cleanrota.app.domain.Member
import com.cleanrota.app.domain.RotaState
import com.cleanrota.app.domain.Substitution
import java.time.LocalDate
import org.json.JSONArray
import org.json.JSONObject

/** تحويل الحالة من/إلى JSON (منفصل عن Android كي يمكن اختباره). */
object StateCodec {

    fun encode(s: RotaState): String = JSONObject().apply {
        put("version", 1)
        put("startDate", s.startDate.toString())
        put("cycleIndex", s.cycleIndex)
        put("members", JSONArray().also { arr ->
            s.members.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("active", it.active)) }
        })
        put("queue", JSONArray(s.queue))
        put("exemptNext", JSONArray(s.exemptNext))
        put("pending", JSONArray().also { arr ->
            s.pending.forEach { arr.put(JSONObject().put("absent", it.absentId).put("sub", it.substituteId)) }
        })
        put("history", JSONArray().also { arr ->
            s.history.forEach { h ->
                arr.put(
                    JSONObject()
                        .put("date", h.date.toString())
                        .put("team", JSONArray(h.team))
                        .put("subs", JSONArray().also { sa ->
                            h.substitutions.forEach { (a, b) -> sa.put(JSONObject().put("absent", a).put("sub", b)) }
                        })
                )
            }
        })
    }.toString()

    fun decode(json: String): RotaState {
        val o = JSONObject(json)
        return RotaState(
            startDate = LocalDate.parse(o.getString("startDate")),
            cycleIndex = o.getInt("cycleIndex"),
            members = o.getJSONArray("members").objects().map {
                Member(it.getString("id"), it.getString("name"), it.optBoolean("active", true))
            },
            queue = o.getJSONArray("queue").strings(),
            exemptNext = o.optJSONArray("exemptNext")?.strings() ?: emptyList(),
            pending = o.getJSONArray("pending").objects().map {
                Substitution(it.getString("absent"), it.getString("sub"))
            },
            history = o.getJSONArray("history").objects().map { h ->
                HistoryEntry(
                    date = LocalDate.parse(h.getString("date")),
                    team = h.getJSONArray("team").strings(),
                    substitutions = h.getJSONArray("subs").objects().map { it.getString("absent") to it.getString("sub") }
                )
            }
        )
    }

    private fun JSONArray.strings(): List<String> = List(length()) { getString(it) }
    private fun JSONArray.objects(): List<JSONObject> = List(length()) { getJSONObject(it) }
}

/** تخزين محلي بسيط عبر SharedPreferences. */
class RotaStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("cleanrota", Context.MODE_PRIVATE)

    fun load(today: LocalDate): RotaState {
        val raw = prefs.getString(KEY, null) ?: return RotaState(startDate = today)
        return try {
            StateCodec.decode(raw)
        } catch (e: Exception) {
            RotaState(startDate = today) // بيانات تالفة: نبدأ من جديد بدل تعطل التطبيق
        }
    }

    fun save(state: RotaState) {
        prefs.edit().putString(KEY, StateCodec.encode(state)).apply()
    }

    private companion object {
        const val KEY = "state_v1"
    }
}
