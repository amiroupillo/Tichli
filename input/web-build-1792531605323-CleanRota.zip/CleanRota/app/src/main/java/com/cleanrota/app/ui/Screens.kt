package com.cleanrota.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cleanrota.app.domain.RotaState
import com.cleanrota.app.domain.Scheduler
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

// ════════════════════════════ الهيكل العام ════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RotaApp(vm: RotaViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showAdd by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(listOf("جدول التنظيف", "أفراد الفريق", "السجل")[tab]) },
                actions = {
                    if (tab == 0) {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.DateRange, null) }, label = { Text("الجدول") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Person, null) }, label = { Text("الأفراد") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.CheckCircle, null) }, label = { Text("السجل") }
                )
            }
        },
        floatingActionButton = {
            if (tab == 1) {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة فرد")
                }
            }
        }
    ) { padding ->
        val mod = Modifier.padding(padding)
        when (tab) {
            0 -> ScheduleScreen(
                state = state,
                onSetSub = vm::setSubstitute,
                onClearSub = vm::clearSubstitute,
                onComplete = vm::completeSession,
                modifier = mod
            )
            1 -> MembersScreen(
                state = state,
                onToggle = vm::setActive,
                onRename = vm::renameMember,
                onDelete = vm::deleteMember,
                modifier = mod
            )
            else -> HistoryScreen(state = state, modifier = mod)
        }
    }

    if (showAdd) {
        NameDialog(
            title = "إضافة فرد",
            initial = "",
            confirmLabel = "إضافة",
            isTaken = { Scheduler.isNameTaken(state, it) },
            onDismiss = { showAdd = false },
            onConfirm = { vm.addMember(it); showAdd = false }
        )
    }
    if (showSettings) {
        SettingsDialog(
            state = state,
            onDismiss = { showSettings = false },
            onSetStart = vm::setStartDate
        )
    }
}

// ════════════════════════════ شاشة الجدول ════════════════════════════

@Composable
fun ScheduleScreen(
    state: RotaState,
    onSetSub: (absentId: String, substituteId: String) -> Unit,
    onClearSub: (String) -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val names = remember(state.members) { state.members.associate { it.id to it.name } }
    val today = LocalDate.now()
    val base = Scheduler.currentTeam(state)
    val date = Scheduler.sessionDate(state.startDate, state.cycleIndex)
    val exempt = Scheduler.exemptApplied(state)
    val upcoming = remember(state) { Scheduler.project(state, 7).drop(1) }
    var subFor by remember { mutableStateOf<String?>(null) }
    var confirmDone by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (base.isEmpty()) {
            item { InfoCard("لا يوجد أفراد بعد. أضف أفراد الفريق من تبويب «الأفراد» ليبدأ التطبيق بتوزيع المهام.") }
            return@LazyColumn
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("الموعد القادم", style = MaterialTheme.typography.labelLarge)
                    Text(date.arFull(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(relativeLabel(date, today), style = MaterialTheme.typography.bodyMedium)

                    if (base.size < Scheduler.TEAM_SIZE) {
                        Spacer(Modifier.height(8.dp))
                        WarningRow("عدد الأفراد النشطين أقل من ${Scheduler.TEAM_SIZE}؛ أضف أفرادًا لاكتمال الفريق.")
                    }

                    Spacer(Modifier.height(12.dp))
                    Text("فريق التنظيف", style = MaterialTheme.typography.titleSmall)
                    base.forEach { id ->
                        val sub = state.pending.firstOrNull { it.absentId == id }?.substituteId
                        TeamRow(
                            name = names[id] ?: "؟",
                            substituteName = sub?.let { names[it] },
                            onReplace = { subFor = id },
                            onClear = { onClearSub(id) }
                        )
                    }

                    if (exempt.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "معفى من هذا الموعد (خدم بديلًا في الموعد السابق): " +
                                exempt.joinToString("، ") { names[it] ?: "؟" },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { confirmDone = true },
                        enabled = date <= today,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (date <= today) "تم التنظيف ✓" else "يمكن التأكيد يوم الموعد") }
                }
            }
        }

        if (upcoming.isNotEmpty()) {
            item { Text("المواعيد التالية", style = MaterialTheme.typography.titleMedium) }
            items(upcoming) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.date.arFull(), fontWeight = FontWeight.Bold)
                        Text(p.team.joinToString("  •  ") { names[it] ?: "؟" })
                        if (p.exemptApplied.isNotEmpty()) {
                            Text(
                                "معفى: " + p.exemptApplied.joinToString("، ") { names[it] ?: "؟" },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }

    // اختيار البديل
    subFor?.let { absentId ->
        val candidates = Scheduler.eligibleSubstitutes(state, absentId)
        AlertDialog(
            onDismissRequest = { subFor = null },
            title = { Text("بديل ${names[absentId] ?: ""}") },
            text = {
                if (candidates.isEmpty()) {
                    Text("لا يوجد أفراد متاحون ليكونوا بدلاء. أضف فردًا جديدًا أو فعّل فردًا معطّلًا.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        candidates.forEach { id ->
                            val pos = state.queue.indexOf(id) + 1
                            ListItem(
                                headlineContent = { Text(names[id] ?: "؟") },
                                supportingContent = { Text("ترتيبه في الدور: $pos") },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clickable {
                                    onSetSub(absentId, id)
                                    subFor = null
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { subFor = null }) { Text("إلغاء") } }
        )
    }

    // تأكيد الإتمام
    if (confirmDone) {
        AlertDialog(
            onDismissRequest = { confirmDone = false },
            title = { Text("تأكيد إتمام التنظيف") },
            text = {
                Text(
                    "سيُسجَّل الموعد في السجل ويتقدّم الدور. " +
                        "الغائبون يُبرمجون في الموعد التالي، ومشاركة البدلاء تُحتسب بدل دورهم القادم."
                )
            },
            confirmButton = { TextButton(onClick = { onComplete(); confirmDone = false }) { Text("تأكيد") } },
            dismissButton = { TextButton(onClick = { confirmDone = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun TeamRow(name: String, substituteName: String?, onReplace: () -> Unit, onClear: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            if (substituteName == null) {
                Text(name, style = MaterialTheme.typography.titleMedium)
            } else {
                Text(
                    name,
                    style = MaterialTheme.typography.bodyMedium,
                    textDecoration = TextDecoration.LineThrough
                )
                Text(
                    "البديل: $substituteName",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text("$name سيُبرمج في الموعد التالي", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (substituteName == null) {
            TextButton(onClick = onReplace) { Text("غائب؟ استبدال") }
        } else {
            TextButton(onClick = onReplace) { Text("تغيير") }
            TextButton(onClick = onClear) { Text("إلغاء") }
        }
    }
}

private fun relativeLabel(date: LocalDate, today: LocalDate): String {
    val d = ChronoUnit.DAYS.between(today, date)
    return when {
        d == 0L -> "اليوم"
        d == 1L -> "غدًا"
        d == 2L -> "بعد يومين"
        d in 3L..10L -> "بعد $d أيام"
        d > 10L -> "بعد $d يومًا"
        d == -1L -> "متأخر بيوم واحد"
        d == -2L -> "متأخر بيومين"
        else -> "متأخر منذ ${-d} يومًا"
    }
}

@Composable
private fun InfoCard(text: String) {
    Card { Text(text, Modifier.padding(16.dp)) }
}

@Composable
private fun WarningRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
        Spacer(Modifier.padding(horizontal = 4.dp))
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

// ════════════════════════════ شاشة الأفراد ════════════════════════════

@Composable
fun MembersScreen(
    state: RotaState,
    onToggle: (String, Boolean) -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var editing by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }

    // النشطون بترتيب الدور ثم المعطّلون
    val ordered = remember(state) {
        val byId = state.members.associateBy { it.id }
        state.queue.mapNotNull { byId[it] } + state.members.filter { !it.active }
    }

    if (ordered.isEmpty()) {
        Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            InfoCard("القائمة فارغة. اضغط زر (+) لإضافة أول فرد. يلزم 3 أفراد على الأقل لتكوين فريق.")
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(ordered, key = { it.id }) { m ->
            val pos = state.queue.indexOf(m.id) + 1
            Card {
                Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (m.active) "الترتيب في الدور: $pos" else "غير متاح مؤقتًا",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = m.active, onCheckedChange = { onToggle(m.id, it) })
                    IconButton(onClick = { editing = m.id }) { Icon(Icons.Default.Edit, "تحرير") }
                    IconButton(onClick = { deleting = m.id }) { Icon(Icons.Default.Delete, "حذف") }
                }
            }
        }
    }

    editing?.let { id ->
        val member = state.members.firstOrNull { it.id == id }
        if (member != null) {
            NameDialog(
                title = "تحرير الاسم",
                initial = member.name,
                confirmLabel = "حفظ",
                isTaken = { Scheduler.isNameTaken(state, it, exceptId = id) },
                onDismiss = { editing = null },
                onConfirm = { onRename(id, it); editing = null }
            )
        } else editing = null
    }

    deleting?.let { id ->
        val member = state.members.firstOrNull { it.id == id }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف ${member?.name ?: ""}؟") },
            text = { Text("سيُحذف من القائمة والدور. يبقى اسمه في السجل. للغياب المؤقت استخدم المفتاح بدل الحذف.") },
            confirmButton = { TextButton(onClick = { onDelete(id); deleting = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    isTaken: (String) -> Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    val trimmed = text.trim()
    val taken = trimmed.isNotEmpty() && isTaken(trimmed)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("الاسم") },
                isError = taken,
                supportingText = { if (taken) Text("هذا الاسم موجود مسبقًا") }
            )
        },
        confirmButton = {
            TextButton(enabled = trimmed.isNotEmpty() && !taken, onClick = { onConfirm(trimmed) }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ════════════════════════════ شاشة السجل ════════════════════════════

@Composable
fun HistoryScreen(state: RotaState, modifier: Modifier = Modifier) {
    if (state.history.isEmpty()) {
        Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            InfoCard("لا توجد مواعيد منجزة بعد.")
        }
        return
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(state.history.asReversed()) { h ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text(h.date.arFull(), fontWeight = FontWeight.Bold)
                    Text(h.team.joinToString("  •  "))
                    h.substitutions.forEach { (absent, sub) ->
                        Text("$sub بدلًا من $absent", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

// ════════════════════════════ الإعدادات ════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(state: RotaState, onDismiss: () -> Unit, onSetStart: (LocalDate) -> Unit) {
    var picking by remember { mutableStateOf(false) }
    val editable = state.history.isEmpty()

    if (picking) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = state.startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { picking = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let {
                        onSetStart(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                    picking = false
                }) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { picking = false }) { Text("إلغاء") } }
        ) { DatePicker(state = pickerState) }
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الإعدادات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("بداية الدورة الأولى", style = MaterialTheme.typography.labelLarge)
                Text(state.startDate.arFull())
                if (editable) {
                    TextButton(onClick = { picking = true }) { Text("تغيير التاريخ") }
                } else {
                    Text("لا يمكن تغييره بعد إتمام أول موعد.", style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(12.dp))
                Text("كيف تُحسب المواعيد؟", style = MaterialTheme.typography.labelLarge)
                Text(
                    "• الزمن مقسّم إلى دورات من 8 أيام.\n" +
                        "• موعد كل دورة = أول يوم ثلاثاء داخلها (فالموعد ثلاثاء دائمًا، والمتوسط 8 أيام).\n" +
                        "• الفريق = 3 أفراد بالتناوب.\n" +
                        "• الغائب يُبرمج في الموعد التالي.\n" +
                        "• مشاركة البديل تُحتسب بدل دوره القادم، ويُعفى من الموعد التالي إن كان ضمن فريقه.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}
